// ============================================================
// Next.js Middleware — Auth Guard + Onboarding Gate
// Runs on every request (edge runtime).
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { createMiddlewareClient } from './lib/supabase';

// Paths that never require authentication
const PUBLIC_PATHS = [
  '/auth/login',
  '/auth/callback',
  '/auth/error',
  '/_next',
  '/favicon',
  '/api/health',
];

// Only the onboarding path is accessible to unonboarded users
const ONBOARDING_PATH = '/onboarding';

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Skip public assets & routes
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const response = NextResponse.next({
    request: { headers: request.headers },
  });

  const supabase = createMiddlewareClient(request, response);

  // Refresh session (keeps cookies in sync)
  const {
    data: { session },
  } = await supabase.auth.getSession();

  // ── Not authenticated → redirect to login ─────────────
  if (!session) {
    const loginUrl = new URL('/auth/login', request.url);
    loginUrl.searchParams.set('next', pathname);
    return NextResponse.redirect(loginUrl);
  }

  // ── Authenticated: check onboarding status ────────────
  // Skip this check if user is already heading to onboarding
  if (pathname === ONBOARDING_PATH) {
    return response;
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('onboarded')
    .eq('id', session.user.id)
    .single();

  // Profile doesn't exist yet or not onboarded
  if (!profile || !profile.onboarded) {
    return NextResponse.redirect(new URL(ONBOARDING_PATH, request.url));
  }

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths EXCEPT:
     * - _next/static (static files)
     * - _next/image (image optimization)
     * - favicon.ico
     */
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
};
