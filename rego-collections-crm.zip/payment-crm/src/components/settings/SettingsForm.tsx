'use client';

// ============================================================
// SettingsForm — Org name, currency, display preferences
// ============================================================

import { useState } from 'react';
import { Building2, Globe, Mail, CheckCircle2, Loader2, AlertCircle } from 'lucide-react';
import { createClient } from '@/lib/supabase';

const CURRENCIES = [
  { code: 'INR', label: 'Indian Rupee',      symbol: '₹' },
  { code: 'USD', label: 'US Dollar',         symbol: '$' },
  { code: 'EUR', label: 'Euro',              symbol: '€' },
  { code: 'GBP', label: 'British Pound',     symbol: '£' },
  { code: 'AED', label: 'UAE Dirham',        symbol: 'د.إ' },
  { code: 'SGD', label: 'Singapore Dollar',  symbol: 'S$' },
];

interface Props {
  profile: {
    id: string;
    org_name: string | null;
    currency: string;
    full_name: string | null;
    avatar_url: string | null;
  } | null;
  userEmail: string;
}

export default function SettingsForm({ profile, userEmail }: Props) {
  const [orgName,  setOrgName]  = useState(profile?.org_name  ?? '');
  const [currency, setCurrency] = useState(profile?.currency  ?? 'INR');
  const [isSaving, setIsSaving] = useState(false);
  const [status,   setStatus]   = useState<'idle' | 'success' | 'error'>('idle');
  const [errMsg,   setErrMsg]   = useState('');

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!orgName.trim() || orgName.trim().length < 2) {
      setErrMsg('Organisation name must be at least 2 characters.');
      setStatus('error');
      return;
    }
    setIsSaving(true);
    setStatus('idle');

    const supabase = createClient();
    const { error } = await supabase
      .from('profiles')
      .update({ org_name: orgName.trim(), currency })
      .eq('id', profile?.id ?? '');

    setIsSaving(false);
    if (error) {
      setErrMsg(error.message);
      setStatus('error');
    } else {
      setStatus('success');
      setTimeout(() => setStatus('idle'), 3000);
    }
  }

  const initials = (profile?.full_name ?? userEmail)
    .split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();

  return (
    <form onSubmit={handleSave} className="space-y-5">
      {/* Profile card */}
      <div className="bg-white/[0.03] border border-white/6 rounded-2xl p-6 flex items-center gap-5">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500/30 to-indigo-600/30 flex items-center justify-center flex-shrink-0">
          {profile?.avatar_url ? (
            <img src={profile.avatar_url} alt="" className="w-14 h-14 rounded-2xl object-cover" />
          ) : (
            <span className="text-white font-bold text-lg">{initials}</span>
          )}
        </div>
        <div className="min-w-0">
          <p className="text-white font-semibold">{profile?.full_name ?? 'Your Account'}</p>
          <div className="flex items-center gap-1.5 mt-1">
            <Mail className="w-3.5 h-3.5 text-white/25" />
            <p className="text-white/40 text-sm">{userEmail}</p>
          </div>
          <p className="text-white/20 text-xs mt-0.5">Google OAuth account · Read-only</p>
        </div>
      </div>

      {/* Organisation */}
      <div className="bg-white/[0.03] border border-white/6 rounded-2xl p-6 space-y-5">
        <p className="text-white/40 text-xs font-medium uppercase tracking-wider">Organisation</p>

        <div className="space-y-1.5">
          <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
            <Building2 className="w-3.5 h-3.5 text-white/25" />
            Organisation name <span className="text-violet-400">*</span>
          </label>
          <input
            type="text"
            value={orgName}
            onChange={e => setOrgName(e.target.value)}
            placeholder="Rego Mobility Pvt Ltd"
            maxLength={120}
            className="
              w-full px-4 py-2.5 rounded-xl text-sm
              bg-white/[0.04] border border-white/8
              text-white/80 placeholder-white/20
              focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20
              transition-all
            "
          />
        </div>

        <div className="space-y-2">
          <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
            <Globe className="w-3.5 h-3.5 text-white/25" />
            Default currency
          </label>
          <div className="grid grid-cols-3 gap-2">
            {CURRENCIES.map(c => (
              <button
                key={c.code}
                type="button"
                onClick={() => setCurrency(c.code)}
                className={`
                  flex items-center gap-2.5 px-3.5 py-3 rounded-xl border text-left transition-all
                  ${currency === c.code
                    ? 'bg-violet-500/15 border-violet-500/40 text-white'
                    : 'bg-white/3 border-white/8 text-white/35 hover:text-white/60 hover:border-white/15'}
                `}
              >
                <span className="font-mono text-base font-bold leading-none">{c.symbol}</span>
                <div>
                  <p className="text-xs font-semibold">{c.code}</p>
                  <p className="text-[10px] opacity-50 mt-0.5">{c.label}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Feedback */}
      {status === 'success' && (
        <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <p className="text-emerald-300 text-sm">Settings saved successfully.</p>
        </div>
      )}
      {status === 'error' && (
        <div className="flex items-center gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/20">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
          <p className="text-red-300 text-sm">{errMsg}</p>
        </div>
      )}

      {/* Save */}
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={isSaving}
          className="
            flex items-center gap-2 px-6 py-2.5 rounded-xl
            bg-gradient-to-r from-violet-600 to-indigo-600
            hover:from-violet-500 hover:to-indigo-500
            text-white text-sm font-semibold
            disabled:opacity-50 disabled:cursor-not-allowed
            transition-all shadow-lg shadow-violet-500/20
          "
        >
          {isSaving ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</>
          ) : 'Save Settings'}
        </button>
      </div>
    </form>
  );
}
