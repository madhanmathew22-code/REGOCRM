'use client';

// ============================================================
// AnalyticsCharts — Full analytics view with multiple charts
// ============================================================

import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { formatCurrency, shortCurrency } from '@/lib/utils';

const STATUS_COLORS: Record<string, string> = {
  paid:    '#10B981',
  sent:    '#3B82F6',
  draft:   '#6B7280',
  overdue: '#EF4444',
  partial: '#F59E0B',
};

interface Props {
  monthlyTrend: { month: string; invoiced: number; collected: number; overdue: number; count: number }[];
  statusBreakdown: { status: string; count: number; amount: number }[];
  topCustomers: { name: string; company: string | null; total: number; paid: number }[];
  currency: string;
  totalCustomers: number;
  totalPayments: number;
}

function ChartTooltip({ active, payload, label, currency }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#16162A] border border-white/10 rounded-xl p-3 shadow-2xl text-xs min-w-[140px]">
      <p className="text-white/50 font-medium mb-2">{label}</p>
      {payload.map((entry: any) => (
        <div key={entry.name} className="flex items-center justify-between gap-4 mb-1">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full" style={{ background: entry.color || entry.fill }} />
            <span className="text-white/40 capitalize">{entry.name}</span>
          </div>
          <span className="text-white font-semibold">
            {typeof entry.value === 'number' && entry.value > 100
              ? formatCurrency(entry.value, currency)
              : entry.value}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function AnalyticsCharts({
  monthlyTrend,
  statusBreakdown,
  topCustomers,
  currency,
  totalCustomers,
  totalPayments,
}: Props) {
  const totalInvoiced  = monthlyTrend.reduce((s, m) => s + m.invoiced, 0);
  const totalCollected = monthlyTrend.reduce((s, m) => s + m.collected, 0);
  const collRate       = totalInvoiced > 0 ? Math.round((totalCollected / totalInvoiced) * 100) : 0;

  const hasTrendData = monthlyTrend.some(m => m.invoiced > 0);
  const hasStatusData = statusBreakdown.some(s => s.count > 0);

  return (
    <div className="space-y-6">
      {/* KPI row */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Total Invoiced',   value: formatCurrency(totalInvoiced, currency),  sub: 'Last 12 months' },
          { label: 'Total Collected',  value: formatCurrency(totalCollected, currency), sub: 'Cash received' },
          { label: 'Collection Rate',  value: `${collRate}%`,                           sub: collRate >= 80 ? '✓ On target' : '⚠ Below 80%' },
          { label: 'Active Customers', value: totalCustomers.toString(),                 sub: `${totalPayments} invoices total` },
        ].map(kpi => (
          <div key={kpi.label} className="bg-white/[0.03] border border-white/5 rounded-2xl p-5">
            <p className="text-white/30 text-xs font-medium">{kpi.label}</p>
            <p className="text-2xl font-bold text-white mt-2 tracking-tight">{kpi.value}</p>
            <p className="text-white/25 text-[11px] mt-1">{kpi.sub}</p>
          </div>
        ))}
      </div>

      {/* 12-month area chart */}
      <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-white font-semibold tracking-tight">12-Month Collection Trend</h2>
            <p className="text-white/30 text-xs mt-0.5">Invoiced vs collected vs overdue</p>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            {[
              { color: '#8B5CF6', label: 'Collected' },
              { color: 'rgba(99,102,241,0.4)', label: 'Invoiced' },
              { color: '#EF4444', label: 'Overdue' },
            ].map(({ color, label }) => (
              <div key={label} className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-sm" style={{ background: color }} />
                <span className="text-white/40">{label}</span>
              </div>
            ))}
          </div>
        </div>
        {!hasTrendData ? (
          <div className="h-60 flex items-center justify-center">
            <p className="text-white/20 text-sm">No data yet. Create your first invoice to see trends.</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={monthlyTrend} margin={{ top: 0, right: 0, left: -10, bottom: 0 }}>
              <defs>
                <linearGradient id="gradCollected" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#8B5CF6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradInvoiced" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#6366F1" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#6366F1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => shortCurrency(v, currency)} />
              <Tooltip content={<ChartTooltip currency={currency} />} />
              <Area type="monotone" dataKey="invoiced"  stroke="#6366F1" strokeWidth={2} fill="url(#gradInvoiced)"  name="invoiced" />
              <Area type="monotone" dataKey="collected" stroke="#8B5CF6" strokeWidth={2} fill="url(#gradCollected)" name="collected" />
              <Area type="monotone" dataKey="overdue"   stroke="#EF4444" strokeWidth={1.5} fill="rgba(239,68,68,0.05)" name="overdue" strokeDasharray="4 3" />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </div>

      {/* Bottom row: status breakdown + top customers */}
      <div className="grid grid-cols-12 gap-6">
        {/* Pie chart */}
        <div className="col-span-5 bg-white/[0.03] border border-white/5 rounded-2xl p-6">
          <h2 className="text-white font-semibold tracking-tight mb-1">Invoice Status Mix</h2>
          <p className="text-white/30 text-xs mb-6">Count by current status</p>
          {!hasStatusData ? (
            <div className="h-48 flex items-center justify-center">
              <p className="text-white/20 text-sm">No invoice data yet.</p>
            </div>
          ) : (
            <div className="flex items-center gap-4">
              <ResponsiveContainer width="50%" height={180}>
                <PieChart>
                  <Pie
                    data={statusBreakdown.filter(s => s.count > 0)}
                    dataKey="count"
                    nameKey="status"
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={3}
                  >
                    {statusBreakdown.map(s => (
                      <Cell key={s.status} fill={STATUS_COLORS[s.status] ?? '#6B7280'} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTooltip currency={currency} />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2.5 flex-1">
                {statusBreakdown.filter(s => s.count > 0).map(s => (
                  <div key={s.status} className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: STATUS_COLORS[s.status] }} />
                      <span className="text-white/50 text-xs capitalize">{s.status}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-white/70 text-xs font-mono">{s.count}</span>
                      <span className="text-white/20 text-[10px] ml-1">inv</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Top customers bar chart */}
        <div className="col-span-7 bg-white/[0.03] border border-white/5 rounded-2xl p-6">
          <h2 className="text-white font-semibold tracking-tight mb-1">Top Clients by Volume</h2>
          <p className="text-white/30 text-xs mb-6">Total invoiced amount per customer</p>
          {topCustomers.length === 0 ? (
            <div className="h-48 flex items-center justify-center">
              <p className="text-white/20 text-sm">No customer data yet.</p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart
                data={topCustomers}
                layout="vertical"
                margin={{ top: 0, right: 16, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
                <XAxis
                  type="number"
                  tick={{ fill: 'rgba(255,255,255,0.25)', fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={v => shortCurrency(v, currency)}
                />
                <YAxis
                  type="category"
                  dataKey="name"
                  tick={{ fill: 'rgba(255,255,255,0.45)', fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  width={90}
                  tickFormatter={v => v.length > 12 ? v.slice(0, 11) + '…' : v}
                />
                <Tooltip content={<ChartTooltip currency={currency} />} />
                <Bar dataKey="total" name="invoiced" fill="rgba(99,102,241,0.5)" radius={[0, 4, 4, 0]} maxBarSize={18} />
                <Bar dataKey="paid"  name="collected" fill="rgba(139,92,246,0.8)" radius={[0, 4, 4, 0]} maxBarSize={18} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}
