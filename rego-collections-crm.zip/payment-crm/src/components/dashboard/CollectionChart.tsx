'use client';

// ============================================================
// CollectionChart — Month-over-month bar + line chart
// ============================================================

import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { formatCurrency, shortCurrency } from '@/lib/utils';

interface MonthlyData {
  month: string;
  collected: number;
  invoiced: number;
  overdue: number;
}

interface Props {
  data: MonthlyData[];
  currency: string;
}

function CustomTooltip({ active, payload, label, currency }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#16162A] border border-white/10 rounded-xl p-3 shadow-2xl text-xs min-w-[160px]">
      <p className="text-white/50 font-medium mb-2">{label}</p>
      {payload.map((entry: any) => (
        <div key={entry.name} className="flex items-center justify-between gap-4 mb-1">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full" style={{ background: entry.color }} />
            <span className="text-white/50 capitalize">{entry.name}</span>
          </div>
          <span className="text-white font-semibold">
            {formatCurrency(entry.value, currency)}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function CollectionChart({ data, currency }: Props) {
  return (
    <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-white font-semibold text-base tracking-tight">
            Collection Trend
          </h2>
          <p className="text-white/30 text-xs mt-0.5">Month-over-month performance</p>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          {[
            { color: '#8B5CF6', label: 'Collected' },
            { color: '#1E40AF', label: 'Invoiced' },
            { color: '#EF4444', label: 'Overdue' },
          ].map(({ color, label }) => (
            <div key={label} className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-sm" style={{ background: color }} />
              <span className="text-white/40">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {data.every(d => d.collected === 0 && d.invoiced === 0) ? (
        <div className="h-56 flex items-center justify-center">
          <p className="text-white/20 text-sm">No payment data yet. Start by adding invoices.</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <ComposedChart data={data} margin={{ top: 0, right: 0, left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
            <XAxis
              dataKey="month"
              tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              tickFormatter={(v) => shortCurrency(v, currency)}
            />
            <Tooltip content={<CustomTooltip currency={currency} />} />
            <Bar dataKey="invoiced" fill="rgba(30,64,175,0.4)" radius={[4, 4, 0, 0]} maxBarSize={32} name="invoiced" />
            <Bar dataKey="collected" fill="rgba(139,92,246,0.7)" radius={[4, 4, 0, 0]} maxBarSize={32} name="collected" />
            <Line
              type="monotone"
              dataKey="overdue"
              stroke="#EF4444"
              strokeWidth={2}
              dot={{ fill: '#EF4444', r: 3, strokeWidth: 0 }}
              name="overdue"
            />
          </ComposedChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
