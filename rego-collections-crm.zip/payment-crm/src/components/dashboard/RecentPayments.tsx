'use client';

// ============================================================
// RecentPayments — Compact list for dashboard sidebar
// ============================================================

import { formatCurrency } from '@/lib/utils';
import { ExternalLink } from 'lucide-react';
import Link from 'next/link';

const STATUS_STYLES: Record<string, string> = {
  paid:    'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
  overdue: 'bg-red-500/15 text-red-400 border-red-500/20',
  sent:    'bg-blue-500/15 text-blue-400 border-blue-500/20',
  draft:   'bg-white/8 text-white/40 border-white/10',
  partial: 'bg-amber-500/15 text-amber-400 border-amber-500/20',
};

interface Payment {
  id: string;
  amount: number;
  amount_paid: number;
  status: string;
  created_at: string;
  customers?: { name: string; company: string | null } | null;
}

interface Props {
  payments: Payment[];
  currency: string;
}

export default function RecentPayments({ payments, currency }: Props) {
  return (
    <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-white font-semibold text-base tracking-tight">Recent Invoices</h2>
          <p className="text-white/30 text-xs mt-0.5">Latest activity</p>
        </div>
        <Link
          href="/dashboard/payments"
          className="flex items-center gap-1 text-violet-400 text-xs hover:text-violet-300 transition-colors"
        >
          View all <ExternalLink className="w-3 h-3" />
        </Link>
      </div>

      {payments.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <p className="text-white/20 text-sm text-center">
            No invoices yet.<br />
            <Link href="/dashboard/payments/new" className="text-violet-400 hover:text-violet-300 mt-1 inline-block">
              Create your first →
            </Link>
          </p>
        </div>
      ) : (
        <div className="space-y-2 flex-1 overflow-y-auto">
          {payments.map((p) => (
            <Link
              key={p.id}
              href={`/dashboard/payments/${p.id}`}
              className="flex items-center justify-between p-3 rounded-xl hover:bg-white/5 transition-colors group"
            >
              <div className="min-w-0 flex-1 mr-3">
                <p className="text-white/80 text-sm font-medium truncate group-hover:text-white transition-colors">
                  {p.customers?.name ?? 'Unknown client'}
                </p>
                {p.customers?.company && (
                  <p className="text-white/25 text-[11px] truncate mt-0.5">
                    {p.customers.company}
                  </p>
                )}
              </div>
              <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                <span className="text-white/80 text-sm font-semibold">
                  {formatCurrency(p.amount, currency)}
                </span>
                <span className={`
                  text-[10px] font-medium px-2 py-0.5 rounded-full border capitalize
                  ${STATUS_STYLES[p.status] ?? STATUS_STYLES.draft}
                `}>
                  {p.status}
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
