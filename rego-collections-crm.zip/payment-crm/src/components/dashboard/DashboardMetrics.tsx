'use client';

// ============================================================
// DashboardMetrics — 4 KPI summary cards
// ============================================================

import { TrendingUp, Clock, AlertTriangle, Percent } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

interface Props {
  totalCollected: number;
  totalPending: number;
  totalOverdue: number;
  collectionRate: number;
  currency: string;
}

export default function DashboardMetrics({
  totalCollected,
  totalPending,
  totalOverdue,
  collectionRate,
  currency,
}: Props) {
  const cards = [
    {
      label: 'Total Collected',
      value: formatCurrency(totalCollected, currency),
      icon: TrendingUp,
      iconBg: 'bg-emerald-500/15',
      iconColor: 'text-emerald-400',
      borderColor: 'border-emerald-500/10',
      trend: '+12% vs last month',
      trendPositive: true,
    },
    {
      label: 'Pending',
      value: formatCurrency(totalPending, currency),
      icon: Clock,
      iconBg: 'bg-amber-500/15',
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-500/10',
      trend: 'Awaiting collection',
      trendPositive: null,
    },
    {
      label: 'Overdue',
      value: formatCurrency(totalOverdue, currency),
      icon: AlertTriangle,
      iconBg: 'bg-red-500/15',
      iconColor: 'text-red-400',
      borderColor: 'border-red-500/10',
      trend: 'Requires escalation',
      trendPositive: false,
    },
    {
      label: 'Collection Rate',
      value: `${collectionRate}%`,
      icon: Percent,
      iconBg: 'bg-violet-500/15',
      iconColor: 'text-violet-400',
      borderColor: 'border-violet-500/10',
      trend: collectionRate >= 80 ? 'On target' : 'Below target',
      trendPositive: collectionRate >= 80,
    },
  ];

  return (
    <div className="grid grid-cols-4 gap-4">
      {cards.map((card) => (
        <div
          key={card.label}
          className={`
            relative overflow-hidden
            bg-white/[0.03] border ${card.borderColor}
            rounded-2xl p-5
            hover:bg-white/[0.05] transition-colors
          `}
        >
          {/* Icon */}
          <div className={`w-10 h-10 rounded-xl ${card.iconBg} flex items-center justify-center mb-4`}>
            <card.icon className={`w-5 h-5 ${card.iconColor}`} />
          </div>

          {/* Value */}
          <p className="text-2xl font-bold text-white tracking-tight">{card.value}</p>

          {/* Label */}
          <p className="text-white/40 text-xs font-medium mt-1">{card.label}</p>

          {/* Trend */}
          <p className={`
            text-[11px] mt-3 font-medium
            ${card.trendPositive === true ? 'text-emerald-400' :
              card.trendPositive === false ? 'text-red-400' :
              'text-white/30'}
          `}>
            {card.trend}
          </p>

          {/* Subtle corner glow */}
          <div className={`
            absolute -top-6 -right-6 w-20 h-20 rounded-full blur-2xl opacity-20
            ${card.iconBg}
          `} />
        </div>
      ))}
    </div>
  );
}
