'use client';

// ============================================================
// CustomerForm — Create / edit a customer
// ============================================================

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { User, Mail, Phone, Building2, Tag, FileText, CheckCircle2, Loader2 } from 'lucide-react';
import { createClient } from '@/lib/supabase';

interface CustomerData {
  id?: string;
  name?: string;
  email?: string | null;
  phone?: string | null;
  company?: string | null;
  status?: string;
  notes?: string | null;
  tags?: string[] | null;
}

interface Props {
  userId: string;
  initial?: CustomerData;
}

const STATUS_OPTIONS = [
  { value: 'active',   label: 'Active' },
  { value: 'inactive', label: 'Inactive' },
  { value: 'blocked',  label: 'Blocked' },
];

export default function CustomerForm({ userId, initial }: Props) {
  const router = useRouter();
  const isEdit = !!initial?.id;

  const [form, setForm] = useState({
    name:    initial?.name    ?? '',
    email:   initial?.email   ?? '',
    phone:   initial?.phone   ?? '',
    company: initial?.company ?? '',
    status:  initial?.status  ?? 'active',
    notes:   initial?.notes   ?? '',
    tags:    (initial?.tags ?? []).join(', '),
  });
  const [errors, setErrors]   = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess]     = useState(false);

  function set(field: string, value: string) {
    setForm(f => ({ ...f, [field]: value }));
    setErrors(e => ({ ...e, [field]: '' }));
  }

  function validate(): boolean {
    const errs: Record<string, string> = {};
    if (!form.name.trim() || form.name.trim().length < 2)
      errs.name = 'Name must be at least 2 characters.';
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()))
      errs.email = 'Enter a valid email address.';
    if (form.phone && !/^[+\d\s\-().]{7,15}$/.test(form.phone.trim()))
      errs.phone = 'Enter a valid phone number.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate() || isLoading) return;

    setIsLoading(true);
    const supabase = createClient();

    const payload = {
      user_id: userId,
      name:    form.name.trim(),
      email:   form.email.trim() || null,
      phone:   form.phone.trim() || null,
      company: form.company.trim() || null,
      status:  form.status,
      notes:   form.notes.trim() || null,
      tags:    form.tags ? form.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
    };

    let error;
    if (isEdit && initial?.id) {
      ({ error } = await supabase.from('customers').update(payload).eq('id', initial.id));
    } else {
      ({ error } = await supabase.from('customers').insert(payload));
    }

    setIsLoading(false);
    if (error) {
      setErrors({ _global: error.message });
    } else {
      setSuccess(true);
      setTimeout(() => router.push('/dashboard/customers'), 900);
    }
  }

  if (success) {
    return (
      <div className="flex flex-col items-center gap-4 py-16">
        <div className="w-14 h-14 rounded-full bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center">
          <CheckCircle2 className="w-7 h-7 text-emerald-400" />
        </div>
        <p className="text-white font-semibold">Customer {isEdit ? 'updated' : 'created'}!</p>
        <p className="text-white/30 text-sm">Redirecting…</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {errors._global && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
          <p className="text-red-300 text-sm">{errors._global}</p>
        </div>
      )}

      <div className="bg-white/[0.03] border border-white/6 rounded-2xl p-6 space-y-5">
        <p className="text-white/40 text-xs font-medium uppercase tracking-wider">Contact Details</p>

        {/* Name */}
        <Field
          icon={User}
          label="Full name"
          required
          error={errors.name}
        >
          <input
            type="text"
            value={form.name}
            onChange={e => set('name', e.target.value)}
            placeholder="Rajesh Kumar"
            className={inputClass(!!errors.name)}
          />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          {/* Email */}
          <Field icon={Mail} label="Email address" error={errors.email}>
            <input
              type="email"
              value={form.email}
              onChange={e => set('email', e.target.value)}
              placeholder="rajesh@company.com"
              className={inputClass(!!errors.email)}
            />
          </Field>

          {/* Phone */}
          <Field icon={Phone} label="Phone / mobile" error={errors.phone}>
            <input
              type="tel"
              value={form.phone}
              onChange={e => set('phone', e.target.value)}
              placeholder="+91 98765 43210"
              className={inputClass(!!errors.phone)}
            />
          </Field>
        </div>

        {/* Company */}
        <Field icon={Building2} label="Company / organisation">
          <input
            type="text"
            value={form.company}
            onChange={e => set('company', e.target.value)}
            placeholder="Honeywell Technology Solutions"
            className={inputClass(false)}
          />
        </Field>
      </div>

      <div className="bg-white/[0.03] border border-white/6 rounded-2xl p-6 space-y-5">
        <p className="text-white/40 text-xs font-medium uppercase tracking-wider">Account Settings</p>

        {/* Status */}
        <div className="space-y-1.5">
          <label className="block text-sm font-medium text-white/50">Status</label>
          <div className="flex items-center gap-2">
            {STATUS_OPTIONS.map(opt => (
              <button
                key={opt.value}
                type="button"
                onClick={() => set('status', opt.value)}
                className={`
                  px-4 py-2 rounded-xl border text-sm font-medium transition-all
                  ${form.status === opt.value
                    ? 'bg-violet-500/15 border-violet-500/40 text-violet-300'
                    : 'bg-white/3 border-white/8 text-white/35 hover:text-white/60'}
                `}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tags */}
        <Field icon={Tag} label="Tags (comma-separated)">
          <input
            type="text"
            value={form.tags}
            onChange={e => set('tags', e.target.value)}
            placeholder="enterprise, priority, Q2"
            className={inputClass(false)}
          />
        </Field>

        {/* Notes */}
        <Field icon={FileText} label="Internal notes">
          <textarea
            value={form.notes}
            onChange={e => set('notes', e.target.value)}
            placeholder="Any relevant context about this client…"
            rows={3}
            className={inputClass(false) + ' resize-none'}
          />
        </Field>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between pt-1">
        <button
          type="button"
          onClick={() => router.back()}
          className="px-4 py-2.5 rounded-xl text-white/40 hover:text-white text-sm font-medium hover:bg-white/5 transition-all"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isLoading}
          className="
            flex items-center gap-2 px-6 py-2.5 rounded-xl
            bg-gradient-to-r from-violet-600 to-indigo-600
            hover:from-violet-500 hover:to-indigo-500
            text-white text-sm font-semibold
            disabled:opacity-50 disabled:cursor-not-allowed
            transition-all shadow-lg shadow-violet-500/20
          "
        >
          {isLoading ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</>
          ) : (
            <>{isEdit ? 'Update Customer' : 'Create Customer'}</>
          )}
        </button>
      </div>
    </form>
  );
}

function Field({
  icon: Icon,
  label,
  required,
  error,
  children,
}: {
  icon: any;
  label: string;
  required?: boolean;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
        <Icon className="w-3.5 h-3.5 text-white/25" />
        {label}
        {required && <span className="text-violet-400">*</span>}
      </label>
      {children}
      {error && <p className="text-red-400/80 text-xs">{error}</p>}
    </div>
  );
}

function inputClass(hasError: boolean): string {
  return `
    w-full px-4 py-2.5 rounded-xl text-sm
    bg-white/[0.04] border
    text-white/80 placeholder-white/20
    focus:outline-none focus:ring-1 transition-all
    ${hasError
      ? 'border-red-500/40 focus:border-red-500/60 focus:ring-red-500/20'
      : 'border-white/8 focus:border-violet-500/50 focus:ring-violet-500/20'
    }
  `;
}
