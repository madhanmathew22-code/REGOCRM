'use client';

// ============================================================
// CustomersTable — Searchable, filterable customer list
// ============================================================

import { useState, useMemo } from 'react';
import Link from 'next/link';
import {
  Search, ChevronUp, ChevronDown, ExternalLink,
  Building2, Mail, Phone, MoreHorizontal
} from 'lucide-react';
import { formatCurrency } from '@/lib/utils';

type SortKey = 'name' | 'company' | 'status' | 'total' | 'created_at';
type SortDir = 'asc' | 'desc';

const STATUS_BADGE: Record<string, string> = {
  active:   'bg-emerald-500/12 text-emerald-400 border-emerald-500/20',
  inactive: 'bg-white/8 text-white/35 border-white/10',
  blocked:  'bg-red-500/12 text-red-400 border-red-500/20',
};

interface CustomerRow {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  company: string | null;
  status: string;
  created_at: string;
  payments?: { amount: number; amount_paid: number; status: string }[];
}

interface Props {
  customers: CustomerRow[];
  currency: string;
}

export default function CustomersTable({ customers, currency }: Props) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortKey, setSortKey] = useState<SortKey>('created_at');
  const [sortDir, setSortDir] = useState<SortDir>('desc');

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  }

  const filtered = useMemo(() => {
    let rows = customers;

    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.company?.toLowerCase().includes(q) ||
        c.email?.toLowerCase().includes(q)
      );
    }

    if (statusFilter !== 'all') {
      rows = rows.filter(c => c.status === statusFilter);
    }

    return [...rows].sort((a, b) => {
      let av: any, bv: any;
      if (sortKey === 'total') {
        av = (a.payments ?? []).reduce((s, p) => s + Number(p.amount), 0);
        bv = (b.payments ?? []).reduce((s, p) => s + Number(p.amount), 0);
      } else {
        av = (a as any)[sortKey] ?? '';
        bv = (b as any)[sortKey] ?? '';
      }
      const cmp = av < bv ? -1 : av > bv ? 1 : 0;
      return sortDir === 'asc' ? cmp : -cmp;
    });
  }, [customers, search, statusFilter, sortKey, sortDir]);

  function SortIcon({ col }: { col: SortKey }) {
    if (sortKey !== col) return <ChevronUp className="w-3 h-3 text-white/15" />;
    return sortDir === 'asc'
      ? <ChevronUp className="w-3 h-3 text-violet-400" />
      : <ChevronDown className="w-3 h-3 text-violet-400" />;
  }

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/25" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name, company, email…"
            className="
              w-full pl-10 pr-4 py-2.5 rounded-xl
              bg-white/[0.04] border border-white/8
              text-white/80 placeholder-white/20 text-sm
              focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20
              transition-all
            "
          />
        </div>

        {/* Status filter */}
        <div className="flex items-center gap-1.5 bg-white/[0.03] border border-white/8 rounded-xl p-1">
          {['all', 'active', 'inactive', 'blocked'].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`
                px-3.5 py-1.5 rounded-lg text-xs font-medium capitalize transition-all
                ${statusFilter === s
                  ? 'bg-white/10 text-white'
                  : 'text-white/35 hover:text-white/60'
                }
              `}
            >
              {s}
            </button>
          ))}
        </div>

        <p className="text-white/25 text-xs ml-auto">
          {filtered.length} of {customers.length}
        </p>
      </div>

      {/* Table card */}
      <div className="bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-20 text-center">
            <p className="text-white/20 text-sm">No customers match your search.</p>
          </div>
        ) : (
          <table className="crm-table">
            <thead>
              <tr>
                {[
                  { key: 'name',       label: 'Customer' },
                  { key: 'company',    label: 'Company' },
                  { key: 'status',     label: 'Status' },
                  { key: 'total',      label: 'Total Invoiced' },
                  { key: 'created_at', label: 'Added' },
                ].map(({ key, label }) => (
                  <th key={key}>
                    <button
                      onClick={() => toggleSort(key as SortKey)}
                      className="flex items-center gap-1.5 hover:text-white/60 transition-colors"
                    >
                      {label}
                      <SortIcon col={key as SortKey} />
                    </button>
                  </th>
                ))}
                <th><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => {
                const totalInvoiced = (c.payments ?? []).reduce((s, p) => s + Number(p.amount), 0);
                const totalPaid     = (c.payments ?? []).reduce((s, p) => s + Number(p.amount_paid), 0);
                const initials = c.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();

                return (
                  <tr key={c.id} className="group">
                    {/* Customer */}
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500/30 to-indigo-600/30 flex items-center justify-center flex-shrink-0">
                          <span className="text-violet-300 text-[11px] font-bold">{initials}</span>
                        </div>
                        <div className="min-w-0">
                          <Link
                            href={`/dashboard/customers/${c.id}`}
                            className="text-white/80 font-medium hover:text-white transition-colors truncate block"
                          >
                            {c.name}
                          </Link>
                          {c.email && (
                            <div className="flex items-center gap-1 mt-0.5">
                              <Mail className="w-3 h-3 text-white/20" />
                              <span className="text-white/30 text-[11px] truncate">{c.email}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Company */}
                    <td>
                      {c.company ? (
                        <div className="flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-white/20" />
                          <span className="text-white/55 truncate max-w-[140px]">{c.company}</span>
                        </div>
                      ) : (
                        <span className="text-white/15">—</span>
                      )}
                    </td>

                    {/* Status */}
                    <td>
                      <span className={`
                        text-[11px] font-medium px-2.5 py-1 rounded-full border capitalize
                        ${STATUS_BADGE[c.status] ?? STATUS_BADGE.inactive}
                      `}>
                        {c.status}
                      </span>
                    </td>

                    {/* Total invoiced */}
                    <td>
                      {totalInvoiced > 0 ? (
                        <div>
                          <p className="text-white/70 font-medium font-mono text-sm">
                            {formatCurrency(totalInvoiced, currency)}
                          </p>
                          {totalPaid > 0 && (
                            <p className="text-emerald-400/60 text-[11px] mt-0.5">
                              {formatCurrency(totalPaid, currency)} collected
                            </p>
                          )}
                        </div>
                      ) : (
                        <span className="text-white/15">No invoices</span>
                      )}
                    </td>

                    {/* Added date */}
                    <td>
                      <span className="text-white/30 text-xs">
                        {new Date(c.created_at).toLocaleDateString('en-IN', {
                          day: '2-digit', month: 'short', year: 'numeric'
                        })}
                      </span>
                    </td>

                    {/* Actions */}
                    <td>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Link
                          href={`/dashboard/customers/${c.id}`}
                          className="p-1.5 rounded-lg hover:bg-white/8 text-white/30 hover:text-white/70 transition-all"
                          title="View details"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </Link>
                        {c.phone && (
                          <a
                            href={`tel:${c.phone}`}
                            className="p-1.5 rounded-lg hover:bg-white/8 text-white/30 hover:text-white/70 transition-all"
                            title="Call"
                          >
                            <Phone className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
