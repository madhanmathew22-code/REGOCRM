'use client';

// ============================================================
// StepMapping — Column mapping interface with preview table
// ============================================================

import { ChevronLeft, ChevronRight, ArrowRight, Info } from 'lucide-react';
import { IMPORT_FIELDS } from './ImportWizard';
import type { ColumnMapping, ParsedImportRow, ImportField } from '@/types';

interface Props {
  headers: string[];
  mappings: ColumnMapping[];
  previewRows: ParsedImportRow[];
  onChange: (mappings: ColumnMapping[]) => void;
  onBack: () => void;
  onNext: () => void;
}

const FIELD_COLORS: Partial<Record<ImportField, string>> = {
  name:           'text-violet-300 bg-violet-500/10 border-violet-500/20',
  email:          'text-blue-300 bg-blue-500/10 border-blue-500/20',
  phone:          'text-cyan-300 bg-cyan-500/10 border-cyan-500/20',
  company:        'text-indigo-300 bg-indigo-500/10 border-indigo-500/20',
  amount:         'text-emerald-300 bg-emerald-500/10 border-emerald-500/20',
  due_date:       'text-amber-300 bg-amber-500/10 border-amber-500/20',
  invoice_number: 'text-orange-300 bg-orange-500/10 border-orange-500/20',
  description:    'text-white/40 bg-white/5 border-white/10',
  __skip__:       'text-white/20 bg-transparent border-white/5',
};

export default function StepMapping({ headers, mappings, previewRows, onChange, onBack, onNext }: Props) {
  const hasRequiredName = mappings.some(m => m.mappedField === 'name');

  function updateMapping(excelHeader: string, mappedField: ImportField) {
    onChange(mappings.map(m =>
      m.excelHeader === excelHeader ? { ...m, mappedField } : m
    ));
  }

  // Count how many fields have been mapped (non-skip)
  const mappedCount = mappings.filter(m => m.mappedField !== '__skip__').length;

  return (
    <div className="space-y-5">
      {/* Info bar */}
      <div className="flex items-center gap-3 p-4 rounded-xl bg-violet-500/8 border border-violet-500/15">
        <Info className="w-4 h-4 text-violet-400 flex-shrink-0" />
        <p className="text-violet-200/70 text-sm">
          We've auto-detected <strong className="text-violet-300">{mappedCount}</strong> of{' '}
          {headers.length} columns. Review and adjust the mappings below, then confirm.
        </p>
      </div>

      {/* Mapping grid */}
      <div className="bg-white/[0.03] border border-white/5 rounded-2xl overflow-hidden">
        {/* Table header */}
        <div className="grid grid-cols-[1fr_32px_1fr] gap-4 px-5 py-3 bg-white/3 border-b border-white/5">
          <span className="text-white/40 text-xs font-medium uppercase tracking-wider">Excel Column</span>
          <span />
          <span className="text-white/40 text-xs font-medium uppercase tracking-wider">Maps to CRM Field</span>
        </div>

        {/* Mapping rows */}
        <div className="divide-y divide-white/5">
          {mappings.map(({ excelHeader, mappedField }) => {
            const color = FIELD_COLORS[mappedField] ?? FIELD_COLORS.__skip__!;
            const isSkipped = mappedField === '__skip__';

            return (
              <div
                key={excelHeader}
                className={`
                  grid grid-cols-[1fr_32px_1fr] gap-4 px-5 py-3.5 items-center
                  transition-colors
                  ${isSkipped ? 'opacity-40' : 'hover:bg-white/[0.02]'}
                `}
              >
                {/* Excel header */}
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-2 h-2 rounded-full bg-white/20 flex-shrink-0" />
                  <span className="text-white/70 text-sm font-mono truncate">{excelHeader}</span>
                  {/* Preview values */}
                  <div className="hidden xl:flex items-center gap-1 min-w-0">
                    {previewRows.slice(0, 2).map((row, i) => (
                      <span key={i} className="text-[10px] text-white/20 bg-white/3 border border-white/5 px-1.5 py-0.5 rounded truncate max-w-[80px]">
                        {String(row[excelHeader] ?? '—').slice(0, 14)}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Arrow */}
                <ArrowRight className="w-4 h-4 text-white/15 flex-shrink-0 mx-auto" />

                {/* Field selector */}
                <select
                  value={mappedField}
                  onChange={(e) => updateMapping(excelHeader, e.target.value as ImportField)}
                  className={`
                    w-full px-3 py-2 rounded-lg border text-sm font-medium
                    bg-transparent cursor-pointer
                    focus:outline-none focus:ring-1 focus:ring-violet-500/40
                    transition-all appearance-none
                    ${color}
                  `}
                >
                  {IMPORT_FIELDS.map(f => (
                    <option
                      key={f.value}
                      value={f.value}
                      className="bg-[#16162A] text-white"
                    >
                      {f.label}{f.required ? ' *' : ''}
                    </option>
                  ))}
                </select>
              </div>
            );
          })}
        </div>
      </div>

      {/* Data preview */}
      {previewRows.length > 0 && (
        <div className="bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden">
          <div className="px-5 py-3 border-b border-white/5">
            <p className="text-white/40 text-xs font-medium uppercase tracking-wider">
              Preview — first {previewRows.length} rows
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-white/5">
                  {mappings.filter(m => m.mappedField !== '__skip__').map(m => (
                    <th key={m.excelHeader} className="px-4 py-2.5 text-left text-white/30 font-medium whitespace-nowrap">
                      {IMPORT_FIELDS.find(f => f.value === m.mappedField)?.label ?? m.mappedField}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/3">
                {previewRows.map((row, i) => (
                  <tr key={i} className="hover:bg-white/[0.02]">
                    {mappings.filter(m => m.mappedField !== '__skip__').map(m => (
                      <td key={m.excelHeader} className="px-4 py-2.5 text-white/50 whitespace-nowrap max-w-[160px] truncate">
                        {String(row[m.excelHeader] ?? '—')}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Validation warning */}
      {!hasRequiredName && (
        <div className="flex items-center gap-3 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20">
          <span className="text-amber-400 text-lg">⚠</span>
          <p className="text-amber-300/80 text-sm">
            <strong>Customer Name</strong> is required. Please map at least one column to it.
          </p>
        </div>
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white/50 hover:text-white text-sm font-medium hover:bg-white/5 transition-all"
        >
          <ChevronLeft className="w-4 h-4" />
          Back
        </button>
        <button
          onClick={onNext}
          disabled={!hasRequiredName}
          className="
            flex items-center gap-2 px-5 py-2.5 rounded-xl
            bg-gradient-to-r from-violet-600 to-indigo-600
            hover:from-violet-500 hover:to-indigo-500
            text-white text-sm font-semibold
            disabled:opacity-40 disabled:cursor-not-allowed
            transition-all shadow-lg shadow-violet-500/20
          "
        >
          Validate Data
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
