'use client';

// ============================================================
// StepDone — Import complete screen
// ============================================================

import { CheckCircle2, XCircle, LayoutDashboard, Upload, Users } from 'lucide-react';
import Link from 'next/link';

interface Props {
  importedCount: number;
  errorCount: number;
  onReset: () => void;
}

export default function StepDone({ importedCount, errorCount, onReset }: Props) {
  return (
    <div className="flex flex-col items-center text-center py-16 space-y-8">
      {/* Icon */}
      <div className="relative">
        <div className="w-24 h-24 rounded-full bg-emerald-500/10 border border-emerald-500/25 flex items-center justify-center">
          <CheckCircle2 className="w-12 h-12 text-emerald-400" />
        </div>
        {/* Glow */}
        <div className="absolute inset-0 rounded-full bg-emerald-500/10 blur-xl scale-150 -z-10" />
      </div>

      {/* Title */}
      <div className="space-y-2">
        <h2 className="text-3xl font-bold text-white tracking-tight">Import Complete</h2>
        <p className="text-white/40 text-base max-w-sm">
          Your data has been pushed to Supabase with batch upsert — customers and invoices are ready.
        </p>
      </div>

      {/* Stats */}
      <div className="flex items-center gap-6">
        <div className="flex flex-col items-center gap-1.5 px-8 py-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/15">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <p className="text-3xl font-bold text-white">{importedCount.toLocaleString()}</p>
          <p className="text-emerald-400/70 text-sm">Records imported</p>
        </div>

        {errorCount > 0 && (
          <div className="flex flex-col items-center gap-1.5 px-8 py-5 rounded-2xl bg-red-500/10 border border-red-500/15">
            <XCircle className="w-5 h-5 text-red-400" />
            <p className="text-3xl font-bold text-white">{errorCount.toLocaleString()}</p>
            <p className="text-red-400/70 text-sm">Rows skipped</p>
          </div>
        )}
      </div>

      {/* CTAs */}
      <div className="flex items-center gap-3">
        <Link
          href="/dashboard"
          className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 hover:opacity-90 text-white text-sm font-semibold transition-all shadow-lg shadow-violet-500/20"
        >
          <LayoutDashboard className="w-4 h-4" />
          Go to Dashboard
        </Link>
        <Link
          href="/dashboard/customers"
          className="flex items-center gap-2 px-5 py-3 rounded-xl bg-white/8 border border-white/10 hover:bg-white/12 text-white/70 hover:text-white text-sm font-medium transition-all"
        >
          <Users className="w-4 h-4" />
          View Customers
        </Link>
        <button
          onClick={onReset}
          className="flex items-center gap-2 px-5 py-3 rounded-xl bg-white/5 border border-white/8 hover:bg-white/10 text-white/50 hover:text-white text-sm font-medium transition-all"
        >
          <Upload className="w-4 h-4" />
          Import Another File
        </button>
      </div>
    </div>
  );
}
