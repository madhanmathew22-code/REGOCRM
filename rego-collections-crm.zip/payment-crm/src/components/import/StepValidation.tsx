'use client';

// ============================================================
// StepValidation — Data validation table with row highlights
// ============================================================

import { useState } from 'react';
import { ChevronLeft, AlertTriangle, XCircle, CheckCircle2, Loader2 } from 'lucide-react';
import type { MappedImportRow } from '@/types';

interface Props {
  rows: MappedImportRow[];
  isImporting: boolean;
  onBack: () => void;
  onImport: () => void;
}

type Filter = 'all' | 'error' | 'warning' | 'valid';

const ROW_BG: Record<string, string> = {
  error:   'bg-red-500/5 border-l-2 border-l-red-500/50',
  warning: 'bg-amber-500/5 border-l-2 border-l-amber-500/40',
  valid:   'border-l-2 border-l-transparent',
};

const STATUS_BADGE: Record<string, string> = {
  error:   'bg-red-500/15 text-red-400 border-red-500/20',
  warning: 'bg-amber-500/15 text-amber-400 border-amber-500/20',
  valid:   'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
};

export default function StepValidation({ rows, isImporting, onBack, onImport }: Props) {
  const [filter, setFilter] = useState<Filter>('all');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 15;

  const errorCount   = rows.filter(r => r._validation.status === 'error').length;
  const warningCount = rows.filter(r => r._validation.status === 'warning').length;
  const validCount   = rows.filter(r => r._validation.status === 'valid').length;

  const hasBlockingErrors = errorCount > 0;

  const filtered = rows.filter(r =>
    filter === 'all' ? true : r._validation.status === filter
  );
  const pageCount = Math.ceil(filtered.length / PAGE_SIZE);
  const visible = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  return (
    <div className="space-y-5">
      {/* Summary bar */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { key: 'all',     label: 'Total',    count: rows.length,   icon: null,          color: 'text-white/60' },
          { key: 'valid',   label: 'Valid',    count: validCount,    icon: CheckCircle2,  color: 'text-emerald-400' },
          { key: 'warning', label: 'Warnings', count: warningCount,  icon: AlertTriangle, color: 'text-amber-400' },
          { key: 'error',   label: 'Errors',   count: errorCount,    icon: XCircle,       color: 'text-red-400' },
        ].map(({ key, label, count, icon: Icon, color }) => (
          <button
            key={key}
            onClick={() => { setFilter(key as Filter); setPage(0); }}
            className={`
              flex items-center gap-3 px-4 py-3.5 rounded-xl border text-left
              transition-all
              ${filter === key
                ? 'bg-white/8 border-white/15 text-white'
                : 'bg-white/[0.02] border-white/5 hover:bg-white/5 text-white/50'
              }
            `}
          >
            {Icon && <Icon className={`w-4 h-4 ${color} flex-shrink-0`} />}
            <div>
              <p className="text-lg font-bold text-white leading-none">{count}</p>
              <p className="text-xs text-white/30 mt-0.5">{label}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Blocking error message */}
      {hasBlockingErrors && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/20">
          <XCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-red-300 text-sm font-medium">
              {errorCount} row{errorCount !== 1 ? 's' : ''} have errors and will be skipped during import.
            </p>
            <p className="text-red-400/60 text-xs mt-0.5">
              Fix errors in your source file and re-upload, or proceed to import only valid rows.
            </p>
          </div>
        </div>
      )}

      {/* Data table */}
      <div className="bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5 bg-white/[0.02]">
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium w-12">#</th>
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium">Status</th>
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium">Name</th>
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium">Email</th>
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium">Phone</th>
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium">Company</th>
                <th className="px-4 py-3 text-right text-white/30 text-xs font-medium">Amount</th>
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium">Due Date</th>
                <th className="px-4 py-3 text-left text-white/30 text-xs font-medium">Issues</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {visible.map((row) => {
                const { status, errors, warnings } = row._validation;
                const issues = [...errors, ...warnings];
                return (
                  <tr
                    key={row._validation.rowIndex}
                    className={`${ROW_BG[status]} transition-colors`}
                  >
                    <td className="px-4 py-3 text-white/20 text-xs font-mono">
                      {row._validation.rowIndex + 1}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`
                        text-[10px] font-medium px-2 py-0.5 rounded-full border capitalize
                        ${STATUS_BADGE[status]}
                      `}>
                        {status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`font-medium ${!row.name ? 'text-red-400 italic' : 'text-white/80'}`}>
                        {row.name || '(missing)'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-white/45 max-w-[140px] truncate">
                      {row.email || <span className="text-white/15">—</span>}
                    </td>
                    <td className="px-4 py-3 text-white/45 font-mono text-xs">
                      {row.phone || <span className="text-white/15">—</span>}
                    </td>
                    <td className="px-4 py-3 text-white/45 max-w-[120px] truncate">
                      {row.company || <span className="text-white/15">—</span>}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-white/70">
                      {row.amount !== undefined
                        ? row.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })
                        : <span className="text-white/15">—</span>
                      }
                    </td>
                    <td className="px-4 py-3 text-white/45 text-xs whitespace-nowrap">
                      {row.due_date || <span className="text-white/15">—</span>}
                    </td>
                    <td className="px-4 py-3 max-w-[200px]">
                      {issues.length > 0 ? (
                        <div className="space-y-0.5">
                          {issues.map((issue, i) => (
                            <p key={i} className={`text-[11px] leading-tight ${
                              errors.includes(issue) ? 'text-red-400/80' : 'text-amber-400/70'
                            }`}>
                              {issue}
                            </p>
                          ))}
                        </div>
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500/50" />
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pageCount > 1 && (
          <div className="px-5 py-3 border-t border-white/5 flex items-center justify-between">
            <p className="text-white/25 text-xs">
              Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0}
                className="px-3 py-1.5 rounded-lg bg-white/5 text-white/40 text-xs disabled:opacity-30 hover:bg-white/10 transition-colors"
              >
                ← Prev
              </button>
              <span className="text-white/20 text-xs">{page + 1} / {pageCount}</span>
              <button
                onClick={() => setPage(p => Math.min(pageCount - 1, p + 1))}
                disabled={page >= pageCount - 1}
                className="px-3 py-1.5 rounded-lg bg-white/5 text-white/40 text-xs disabled:opacity-30 hover:bg-white/10 transition-colors"
              >
                Next →
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Import loading skeleton overlay */}
      {isImporting && (
        <div className="flex flex-col items-center gap-4 py-8">
          <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
          <div>
            <p className="text-white font-semibold text-center">Importing to Supabase…</p>
            <p className="text-white/30 text-sm text-center mt-1">
              Batch-upserting {validCount} records. Please wait.
            </p>
          </div>
          {/* Skeleton bars */}
          <div className="w-full max-w-md space-y-2 mt-2">
            {[80, 65, 90, 55, 75].map((w, i) => (
              <div key={i} className="h-2 rounded-full bg-white/5 animate-pulse" style={{ width: `${w}%` }} />
            ))}
          </div>
        </div>
      )}

      {/* Navigation */}
      {!isImporting && (
        <div className="flex items-center justify-between pt-2">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-white/50 hover:text-white text-sm font-medium hover:bg-white/5 transition-all"
          >
            <ChevronLeft className="w-4 h-4" />
            Re-map Columns
          </button>

          <div className="flex items-center gap-3">
            {hasBlockingErrors && (
              <p className="text-white/30 text-xs">
                {validCount + warningCount} rows will be imported
              </p>
            )}
            <button
              onClick={onImport}
              className="
                flex items-center gap-2 px-5 py-2.5 rounded-xl
                bg-gradient-to-r from-emerald-600 to-teal-600
                hover:from-emerald-500 hover:to-teal-500
                text-white text-sm font-semibold
                transition-all shadow-lg shadow-emerald-500/20
              "
            >
              <CheckCircle2 className="w-4 h-4" />
              Import {validCount + warningCount} rows
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
