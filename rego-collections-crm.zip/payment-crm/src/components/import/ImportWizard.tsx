'use client';

// ============================================================
// ImportWizard — 4-step: Upload → Map → Validate → Done
// ============================================================

import { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import StepUpload from './StepUpload';
import StepMapping from './StepMapping';
import StepValidation from './StepValidation';
import StepDone from './StepDone';
import WizardProgress from './WizardProgress';
import type { ImportStep, ColumnMapping, ParsedImportRow, MappedImportRow, ImportField } from '@/types';

export const IMPORT_FIELDS: { value: ImportField; label: string; required?: boolean }[] = [
  { value: 'name',           label: 'Customer Name',   required: true },
  { value: 'email',          label: 'Email Address' },
  { value: 'phone',          label: 'Phone Number' },
  { value: 'company',        label: 'Company / Org' },
  { value: 'amount',         label: 'Invoice Amount' },
  { value: 'due_date',       label: 'Due Date' },
  { value: 'invoice_number', label: 'Invoice Number' },
  { value: 'description',    label: 'Description / Notes' },
  { value: '__skip__',       label: '— Skip this column —' },
];

// ── Email / phone validators ──────────────────────────────
export function isValidEmail(v: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
}
export function isValidPhone(v: string) {
  return /^[+\d\s\-().]{7,15}$/.test(v.trim());
}
export function isValidAmount(v: string | number) {
  return !isNaN(parseFloat(String(v))) && parseFloat(String(v)) >= 0;
}

// ── Auto-guess column mappings from header names ──────────
function guessMapping(header: string): ImportField {
  const h = header.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (/^(name|clientname|customername|billto|party)/.test(h)) return 'name';
  if (/^(email|emailaddress|mail)/.test(h)) return 'email';
  if (/^(phone|mobile|contact|tel)/.test(h)) return 'phone';
  if (/^(company|org|organisation|organization|firm)/.test(h)) return 'company';
  if (/^(amount|amt|total|invoice|invoiceamt|amtdue|balance|value)/.test(h)) return 'amount';
  if (/^(duedate|due|paymentdate|expiry)/.test(h)) return 'due_date';
  if (/^(invoice|invoiceno|invoicenumber|ref|reference)/.test(h)) return 'invoice_number';
  if (/^(desc|description|notes|remarks|narration)/.test(h)) return 'description';
  return '__skip__';
}

// ── Validate a single mapped row ─────────────────────────
export function validateRow(row: Record<string, any>, idx: number): MappedImportRow {
  const errors: string[] = [];
  const warnings: string[] = [];

  const name = String(row.name ?? '').trim();
  if (!name) errors.push('Customer name is required.');

  const email = row.email ? String(row.email).trim() : '';
  if (email && !isValidEmail(email)) warnings.push('Email format looks invalid.');

  const phone = row.phone ? String(row.phone).trim() : '';
  if (phone && !isValidPhone(phone)) warnings.push('Phone format looks unusual.');

  const amount = row.amount !== undefined && row.amount !== '' ? row.amount : undefined;
  if (amount !== undefined && !isValidAmount(amount)) errors.push('Amount must be a positive number.');

  return {
    name,
    email: email || undefined,
    phone: phone || undefined,
    company: row.company ? String(row.company).trim() : undefined,
    amount: amount !== undefined ? parseFloat(String(amount)) : undefined,
    due_date: row.due_date ? String(row.due_date).trim() : undefined,
    invoice_number: row.invoice_number ? String(row.invoice_number).trim() : undefined,
    description: row.description ? String(row.description).trim() : undefined,
    _validation: {
      rowIndex: idx,
      status: errors.length > 0 ? 'error' : warnings.length > 0 ? 'warning' : 'valid',
      errors,
      warnings,
    },
  };
}

// ── Main Wizard component ─────────────────────────────────
export default function ImportWizard() {
  const [step, setStep] = useState<ImportStep>('upload');
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<ParsedImportRow[]>([]);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>([]);
  const [mappedRows, setMappedRows] = useState<MappedImportRow[]>([]);
  const [importedCount, setImportedCount] = useState(0);
  const [errorCount, setErrorCount] = useState(0);

  // ── Parse uploaded file ────────────────────────────────
  const handleFileAccepted = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary', cellDates: true });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const json: any[] = XLSX.utils.sheet_to_json(sheet, { raw: false, defval: '' });

        if (!json.length) return;

        const headers = Object.keys(json[0]);
        const mappings: ColumnMapping[] = headers.map(h => ({
          excelHeader: h,
          mappedField: guessMapping(h),
        }));

        setRawHeaders(headers);
        setRawRows(json as ParsedImportRow[]);
        setColumnMappings(mappings);
        setStep('mapping');
      } catch (err) {
        console.error('Parse error:', err);
      }
    };
    reader.readAsBinaryString(file);
  }, []);

  // ── Apply mappings, validate rows ──────────────────────
  const handleMappingConfirmed = useCallback(() => {
    const mapped = rawRows.map((row, idx) => {
      const remapped: Record<string, any> = {};
      columnMappings.forEach(({ excelHeader, mappedField }) => {
        if (mappedField !== '__skip__') {
          remapped[mappedField] = row[excelHeader];
        }
      });
      return validateRow(remapped, idx);
    });
    setMappedRows(mapped);
    setStep('validation');
  }, [rawRows, columnMappings]);

  // ── Supabase batch upsert ──────────────────────────────
  const handleImport = useCallback(async () => {
    const { createClient } = await import('@/lib/supabase');
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    setStep('importing');

    const validRows = mappedRows.filter(r => r._validation.status !== 'error');
    let imported = 0;
    let errors = 0;

    // Batch upsert customers first
    const BATCH = 50;
    for (let i = 0; i < validRows.length; i += BATCH) {
      const batch = validRows.slice(i, i + BATCH);

      // 1. Upsert customers
      const customerRecords = batch.map(r => ({
        user_id: user.id,
        name: r.name,
        email: r.email ?? null,
        phone: r.phone ?? null,
        company: r.company ?? null,
        status: 'active',
      }));

      const { data: upsertedCustomers, error: custError } = await supabase
        .from('customers')
        .upsert(customerRecords, { onConflict: 'user_id, email', ignoreDuplicates: false })
        .select('id, email, name');

      if (custError) {
        errors += batch.length;
        continue;
      }

      // 2. If payment info present, upsert payments
      const paymentBatch = batch
        .map((r, idx) => {
          const customer = upsertedCustomers?.[idx];
          if (!customer || r.amount === undefined) return null;
          return {
            customer_id: customer.id,
            user_id: user.id,
            amount: r.amount,
            invoice_number: r.invoice_number ?? null,
            due_date: r.due_date ?? null,
            description: r.description ?? null,
            status: 'draft' as const,
            payment_link_mock: `https://pay.rego.co/${Math.random().toString(36).slice(2, 10)}`,
          };
        })
        .filter(Boolean) as any[];

      if (paymentBatch.length) {
        await supabase.from('payments').insert(paymentBatch);
      }

      imported += batch.length;
    }

    setImportedCount(imported);
    setErrorCount(errors);
    setStep('done');
  }, [mappedRows]);

  // ── Reset wizard ───────────────────────────────────────
  const handleReset = useCallback(() => {
    setStep('upload');
    setRawHeaders([]);
    setRawRows([]);
    setColumnMappings([]);
    setMappedRows([]);
    setImportedCount(0);
    setErrorCount(0);
  }, []);

  return (
    <div className="space-y-6">
      <WizardProgress step={step} totalRows={rawRows.length} />

      {step === 'upload' && (
        <StepUpload onFileAccepted={handleFileAccepted} />
      )}

      {step === 'mapping' && (
        <StepMapping
          headers={rawHeaders}
          mappings={columnMappings}
          previewRows={rawRows.slice(0, 5)}
          onChange={setColumnMappings}
          onBack={handleReset}
          onNext={handleMappingConfirmed}
        />
      )}

      {(step === 'validation' || step === 'importing') && (
        <StepValidation
          rows={mappedRows}
          isImporting={step === 'importing'}
          onBack={() => setStep('mapping')}
          onImport={handleImport}
        />
      )}

      {step === 'done' && (
        <StepDone
          importedCount={importedCount}
          errorCount={errorCount}
          onReset={handleReset}
        />
      )}
    </div>
  );
}
