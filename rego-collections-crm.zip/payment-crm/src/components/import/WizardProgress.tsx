'use client';

import { Upload, GitBranch, CheckSquare, Rocket } from 'lucide-react';
import type { ImportStep } from '@/types';

const STEPS: { key: ImportStep; label: string; icon: any }[] = [
  { key: 'upload',     label: 'Upload File',    icon: Upload },
  { key: 'mapping',    label: 'Map Columns',    icon: GitBranch },
  { key: 'validation', label: 'Validate Data',  icon: CheckSquare },
  { key: 'done',       label: 'Import Done',    icon: Rocket },
];

const ORDER: ImportStep[] = ['upload', 'mapping', 'validation', 'importing', 'done'];

interface Props {
  step: ImportStep;
  totalRows?: number;
}

export default function WizardProgress({ step, totalRows }: Props) {
  const currentIdx = ORDER.indexOf(step);

  return (
    <div className="bg-white/[0.03] border border-white/5 rounded-2xl p-5">
      <div className="flex items-center gap-0">
        {STEPS.map((s, i) => {
          const stepIdx = ORDER.indexOf(s.key);
          const isDone    = currentIdx > stepIdx;
          const isActive  = step === s.key || (s.key === 'validation' && step === 'importing');
          const isPending = !isDone && !isActive;

          return (
            <div key={s.key} className="flex items-center flex-1 last:flex-none">
              {/* Step node */}
              <div className="flex flex-col items-center gap-2">
                <div className={`
                  w-9 h-9 rounded-xl flex items-center justify-center border transition-all
                  ${isDone   ? 'bg-violet-500/25 border-violet-500/40 text-violet-300' :
                    isActive ? 'bg-violet-600 border-violet-500 text-white shadow-lg shadow-violet-500/25' :
                               'bg-white/3 border-white/8 text-white/20'}
                `}>
                  <s.icon className="w-4 h-4" />
                </div>
                <span className={`
                  text-[11px] font-medium whitespace-nowrap
                  ${isDone   ? 'text-violet-400' :
                    isActive ? 'text-white' :
                               'text-white/25'}
                `}>
                  {s.label}
                </span>
              </div>

              {/* Connector */}
              {i < STEPS.length - 1 && (
                <div className={`
                  flex-1 h-px mx-3 mb-5 transition-all
                  ${isDone ? 'bg-violet-500/40' : 'bg-white/8'}
                `} />
              )}
            </div>
          );
        })}

        {/* Row count badge */}
        {totalRows && totalRows > 0 && (
          <div className="ml-auto pl-6 flex-none">
            <span className="text-xs text-white/40 bg-white/5 border border-white/8 px-3 py-1.5 rounded-full">
              {totalRows.toLocaleString()} rows detected
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
