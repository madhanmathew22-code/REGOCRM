'use client';

// ============================================================
// StepUpload — Drag-and-drop file uploader
// ============================================================

import { useCallback, useState, useRef } from 'react';
import { Upload, FileSpreadsheet, AlertCircle } from 'lucide-react';

const ACCEPTED = [
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
  'application/vnd.ms-excel', // .xls
  'text/csv',
  '.xlsx', '.xls', '.csv',
];

interface Props {
  onFileAccepted: (file: File) => void;
}

export default function StepUpload({ onFileAccepted }: Props) {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function validateFile(file: File): string | null {
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (!['xlsx', 'xls', 'csv'].includes(ext ?? '')) {
      return 'Only .xlsx, .xls, and .csv files are supported.';
    }
    if (file.size > 10 * 1024 * 1024) {
      return 'File size must be under 10 MB.';
    }
    return null;
  }

  function processFile(file: File) {
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      setSelectedFile(null);
      return;
    }
    setError(null);
    setSelectedFile(file);
    onFileAccepted(file);
  }

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => setIsDragging(false), []);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  }, []);

  const bytesToSize = (b: number) => {
    if (b < 1024) return `${b} B`;
    if (b < 1024 * 1024) return `${(b / 1024).toFixed(1)} KB`;
    return `${(b / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="space-y-5">
      {/* Drop zone */}
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => inputRef.current?.click()}
        className={`
          relative cursor-pointer rounded-2xl border-2 border-dashed p-16
          flex flex-col items-center justify-center text-center
          transition-all duration-200
          ${isDragging
            ? 'border-violet-400/60 bg-violet-500/10 scale-[1.01]'
            : 'border-white/10 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.04]'
          }
        `}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          className="hidden"
          onChange={handleInputChange}
        />

        {selectedFile ? (
          <div className="flex flex-col items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center">
              <FileSpreadsheet className="w-7 h-7 text-emerald-400" />
            </div>
            <div>
              <p className="text-white font-semibold">{selectedFile.name}</p>
              <p className="text-white/40 text-sm mt-0.5">{bytesToSize(selectedFile.size)}</p>
            </div>
            <p className="text-violet-400 text-sm">Parsing file…</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4">
            <div className={`
              w-16 h-16 rounded-2xl flex items-center justify-center border transition-all
              ${isDragging
                ? 'bg-violet-500/20 border-violet-400/40'
                : 'bg-white/5 border-white/10'
              }
            `}>
              <Upload className={`w-7 h-7 ${isDragging ? 'text-violet-300' : 'text-white/30'}`} />
            </div>
            <div>
              <p className="text-white font-semibold text-lg">
                {isDragging ? 'Release to upload' : 'Drop your file here'}
              </p>
              <p className="text-white/40 text-sm mt-1">
                or <span className="text-violet-400 underline underline-offset-2">click to browse</span>
              </p>
            </div>
            <div className="flex items-center gap-2">
              {['.xlsx', '.xls', '.csv'].map(ext => (
                <span key={ext} className="text-xs text-white/25 bg-white/5 border border-white/8 px-2.5 py-1 rounded-full font-mono">
                  {ext}
                </span>
              ))}
              <span className="text-xs text-white/20">· Max 10 MB</span>
            </div>
          </div>
        )}
      </div>

      {/* Error */}
      {error && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/20">
          <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
          <p className="text-red-300 text-sm">{error}</p>
        </div>
      )}

      {/* Template hint */}
      <div className="bg-white/[0.02] border border-white/5 rounded-xl p-5 flex items-start gap-4">
        <FileSpreadsheet className="w-5 h-5 text-white/20 mt-0.5 flex-shrink-0" />
        <div>
          <p className="text-white/50 text-sm font-medium">Expected columns (flexible)</p>
          <p className="text-white/25 text-xs mt-1 leading-relaxed">
            Your file can have any headers — you'll map them in the next step. Common names like
            <span className="font-mono text-white/35"> Client Name</span>,{' '}
            <span className="font-mono text-white/35">Amt Due</span>,{' '}
            <span className="font-mono text-white/35">Mobile</span> are auto-detected.
          </p>
        </div>
      </div>
    </div>
  );
}
