'use client';

// ============================================================
// PaymentsTable — Full invoice management table
// ============================================================

import { useState, useMemo } from 'react';
import Link from 'next/link';
import { Search, ChevronUp, ChevronDown, Copy, ExternalLink, AlertTriangle } from 'lucide-react';
import { formatCurrency, formatDate, relativeDueDate } from '@/lib/utils';

type SortKey = 'customer' | 'amount' | 'status' | 'due_date' | 'created_at';
type SortDir = 'asc' | 'desc';

const STATUS_CONFIG: Record<string, { label: string; style: string }> = {
  draft:   { label: 'Draft',   style: 'bg-white/8 text-white/35 border-white/10' },
  sent:    { label: 'Sent',    style: 'bg-blue-500/12 text-blue-400 border-blue-500/20' },
  paid:    { label: 'Paid',    style: 'bg-emerald-500/12 text-emerald-400 border-emerald-500/20' },
  overdue: { label: 'Overdue', style: 'bg-red-500/12 text-red-400 border-red-500/20' },
  partial: { label: 'Partial', style: 'bg-amber-500/12 text-amber-400 border-amber-500/20' },
};

interface PaymentRow {
  id: string;
  amount: number;
  amount_paid: number;
  status: string;
  invoice_number: string | null;
  due_date: string | null;
  created_at: string;
  customers?: { name: string; email: string | null; company: string | null } | null;
}

interface Props {
  payments: PaymentRow[];
  currency: string;
}

export default function PaymentsTable({ payments, currency }: Props) {
  const [search, setSearch]           = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortKey, setSortKey]         = useState<SortKey>('created_at');
  const [sortDir, setSortDir]         = useState<SortDir>('desc');
  const [copied, setCopied]           = useState<string | null>(null);

  function toggleSort(key: SortKey) {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  }

  async function copyLink(paymentId: string, link: string) {
    await navigator.clipboard.writeText(link);
    setCopied(paymentId);
    setTimeout(() => setCopied(null), 1800);
  }

  const filtered = useMemo(() => {
    let rows = payments;

    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(p =>
        p.customers?.name.toLowerCase().includes(q) ||
        p.customers?.company?.toLowerCase().includes(q) ||
        p.invoice_number?.toLowerCase().includes(q)
      );
    }

    if (statusFilter !== 'all') {
      rows = rows.filter(p => p.status === statusFilter);
    }

    return [...rows].sort((a, b) => {
      let av: any, bv: any;
      switch (sortKey) {
        case 'customer': av = a.customers?.name ?? ''; bv = b.customers?.name ?? ''; break;
        case 'amount':   av = a.amount; bv = b.amount; break;
        case 'due_date': av = a.due_date ?? ''; bv = b.due_date ?? ''; break;
        default:         av = (a as any)[sortKey] ?? ''; bv = (b as any)[sortKey] ?? '';
      }
      const cmp = av < bv ? -1 : av > bv ? 1 : 0;
      return sortDir === 'asc' ? cmp : -cmp;
    });
  }, [payments, search, statusFilter, sortKey, sortDir]);

  function SortIcon({ col }: { col: SortKey }) {
    if (sortKey !== col) return <ChevronUp className="w-3 h-3 text-white/15" />;
    return sortDir === 'asc'
      ? <ChevronUp className="w-3 h-3 text-violet-400" />
      : <ChevronDown className="w-3 h-3 text-violet-400" />;
  }

  // Summary counts by status
  const counts = useMemo(() => {
    return payments.reduce((acc, p) => {
      acc[p.status] = (acc[p.status] ?? 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  }, [payments]);

  return (
    <div className="space-y-4">
      {/* Status filter pills */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => setStatusFilter('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-all ${
            statusFilter === 'all'
              ? 'bg-white/10 border-white/15 text-white'
              : 'bg-white/[0.02] border-white/6 text-white/35 hover:text-white/60'
          }`}
        >
          All ({payments.length})
        </button>
        {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
          <button
            key={key}
            onClick={() => setStatusFilter(key)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-medium border transition-all ${
              statusFilter === key
                ? cfg.style + ' opacity-100'
                : 'bg-white/[0.02] border-white/6 text-white/35 hover:text-white/60'
            }`}
          >
            {cfg.label} {counts[key] ? `(${counts[key]})` : ''}
          </button>
        ))}

        {/* Search */}
        <div className="relative ml-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/25" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search invoices…"
            className="
              pl-9 pr-4 py-2 rounded-xl w-56
              bg-white/[0.04] border border-white/8
              text-white/80 placeholder-white/20 text-xs
              focus:outline-none focus:border-violet-500/50 focus:w-72
              transition-all
            "
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white/[0.02] border border-white/5 rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-20 text-center">
            <p className="text-white/20 text-sm">No invoices found.</p>
          </div>
        ) : (
          <table className="crm-table">
            <thead>
              <tr>
                {[
                  { key: 'customer',   label: 'Client' },
                  { key: 'amount',     label: 'Amount' },
                  { key: 'status',     label: 'Status' },
                  { key: 'due_date',   label: 'Due Date' },
                  { key: 'created_at', label: 'Created' },
                ].map(({ key, label }) => (
                  <th key={key}>
                    <button
                      onClick={() => toggleSort(key as SortKey)}
                      className="flex items-center gap-1.5 hover:text-white/60 transition-colors"
                    >
                      {label}
                      <SortIcon col={key as SortKey} />
                    </button>
                  </th>
                ))}
                <th>Invoice #</th>
                <th><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(p => {
                const status = STATUS_CONFIG[p.status] ?? STATUS_CONFIG.draft;
                const outstanding = Number(p.amount) - Number(p.amount_paid);
                const isOverdue = p.status === 'overdue';
                const dueLabel = p.due_date ? relativeDueDate(p.due_date) : null;
                const mockLink = `https://pay.rego.co/${p.id.slice(0, 8)}`;

                return (
                  <tr key={p.id} className="group">
                    {/* Client */}
                    <td>
                      <div>
                        <Link
                          href={`/dashboard/payments/${p.id}`}
                          className="text-white/80 font-medium hover:text-white transition-colors"
                        >
                          {p.customers?.name ?? 'Unknown'}
                        </Link>
                        {p.customers?.company && (
                          <p className="text-white/25 text-[11px] mt-0.5">{p.customers.company}</p>
                        )}
                      </div>
                    </td>

                    {/* Amount */}
                    <td>
                      <p className="text-white/80 font-semibold font-mono">
                        {formatCurrency(Number(p.amount), currency)}
                      </p>
                      {Number(p.amount_paid) > 0 && p.status !== 'paid' && (
                        <p className="text-emerald-400/60 text-[11px] mt-0.5">
                          {formatCurrency(outstanding, currency)} outstanding
                        </p>
                      )}
                    </td>

                    {/* Status */}
                    <td>
                      <span className={`
                        text-[11px] font-medium px-2.5 py-1 rounded-full border
                        ${status.style}
                      `}>
                        {status.label}
                      </span>
                    </td>

                    {/* Due date */}
                    <td>
                      {p.due_date ? (
                        <div>
                          <p className="text-white/50 text-xs">{formatDate(p.due_date)}</p>
                          {dueLabel && (
                            <p className={`text-[11px] mt-0.5 flex items-center gap-1 ${
                              isOverdue ? 'text-red-400' : 'text-white/25'
                            }`}>
                              {isOverdue && <AlertTriangle className="w-3 h-3" />}
                              {dueLabel}
                            </p>
                          )}
                        </div>
                      ) : (
                        <span className="text-white/15">—</span>
                      )}
                    </td>

                    {/* Created */}
                    <td>
                      <span className="text-white/30 text-xs">
                        {formatDate(p.created_at)}
                      </span>
                    </td>

                    {/* Invoice # */}
                    <td>
                      {p.invoice_number ? (
                        <span className="font-mono text-xs text-white/45">{p.invoice_number}</span>
                      ) : (
                        <span className="text-white/15 text-xs">—</span>
                      )}
                    </td>

                    {/* Actions */}
                    <td>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => copyLink(p.id, mockLink)}
                          className="p-1.5 rounded-lg hover:bg-white/8 text-white/30 hover:text-white/70 transition-all"
                          title="Copy payment link"
                        >
                          {copied === p.id
                            ? <span className="text-[10px] text-emerald-400 px-1">✓</span>
                            : <Copy className="w-3.5 h-3.5" />
                          }
                        </button>
                        <Link
                          href={`/dashboard/payments/${p.id}`}
                          className="p-1.5 rounded-lg hover:bg-white/8 text-white/30 hover:text-white/70 transition-all"
                          title="View"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
