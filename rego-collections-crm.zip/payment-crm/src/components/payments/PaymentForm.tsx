'use client';

// ============================================================
// PaymentForm — Create / edit an invoice
// ============================================================

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { DollarSign, Calendar, FileText, Hash, Link2, CheckCircle2, Loader2, User } from 'lucide-react';
import { createClient } from '@/lib/supabase';
import { getCurrencySymbol, mockPaymentLink } from '@/lib/utils';

interface CustomerOption {
  id: string;
  name: string;
  company: string | null;
}

interface Props {
  userId: string;
  currency: string;
  customers: CustomerOption[];
  initial?: {
    id?: string;
    customer_id?: string;
    amount?: number;
    amount_paid?: number;
    due_date?: string | null;
    invoice_number?: string | null;
    description?: string | null;
    status?: string;
  };
}

const STATUS_OPTIONS = [
  { value: 'draft',   label: 'Draft' },
  { value: 'sent',    label: 'Sent' },
  { value: 'paid',    label: 'Paid' },
  { value: 'overdue', label: 'Overdue' },
  { value: 'partial', label: 'Partial' },
];

const STATUS_COLORS: Record<string, string> = {
  draft:   'bg-white/8 border-white/12 text-white/40',
  sent:    'bg-blue-500/15 border-blue-500/30 text-blue-300',
  paid:    'bg-emerald-500/15 border-emerald-500/30 text-emerald-300',
  overdue: 'bg-red-500/15 border-red-500/30 text-red-300',
  partial: 'bg-amber-500/15 border-amber-500/30 text-amber-300',
};

export default function PaymentForm({ userId, currency, customers, initial }: Props) {
  const router  = useRouter();
  const isEdit  = !!initial?.id;
  const sym     = getCurrencySymbol(currency);

  const [form, setForm] = useState({
    customer_id:    initial?.customer_id    ?? '',
    amount:         String(initial?.amount  ?? ''),
    amount_paid:    String(initial?.amount_paid ?? '0'),
    due_date:       initial?.due_date       ?? '',
    invoice_number: initial?.invoice_number ?? '',
    description:    initial?.description    ?? '',
    status:         initial?.status         ?? 'draft',
  });
  const [errors, setErrors]       = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess]     = useState(false);
  const [generatedLink, setGeneratedLink] = useState<string | null>(null);

  function set(field: string, value: string) {
    setForm(f => ({ ...f, [field]: value }));
    setErrors(e => ({ ...e, [field]: '' }));
  }

  function validate(): boolean {
    const errs: Record<string, string> = {};
    if (!form.customer_id)
      errs.customer_id = 'Select a customer.';
    if (!form.amount || isNaN(parseFloat(form.amount)) || parseFloat(form.amount) < 0)
      errs.amount = 'Enter a valid amount (≥ 0).';
    if (form.amount_paid && (isNaN(parseFloat(form.amount_paid)) || parseFloat(form.amount_paid) < 0))
      errs.amount_paid = 'Enter a valid paid amount.';
    if (form.amount_paid && parseFloat(form.amount_paid) > parseFloat(form.amount))
      errs.amount_paid = 'Paid amount cannot exceed invoice amount.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate() || isLoading) return;

    setIsLoading(true);
    const supabase = createClient();
    const newId    = crypto.randomUUID();
    const link     = mockPaymentLink(isEdit ? (initial?.id ?? newId) : newId);

    const payload = {
      user_id:          userId,
      customer_id:      form.customer_id,
      amount:           parseFloat(form.amount),
      amount_paid:      parseFloat(form.amount_paid || '0'),
      due_date:         form.due_date || null,
      invoice_number:   form.invoice_number.trim() || null,
      description:      form.description.trim() || null,
      status:           form.status,
      payment_link_mock: link,
    };

    let error;
    if (isEdit && initial?.id) {
      ({ error } = await supabase.from('payments').update(payload).eq('id', initial.id));
    } else {
      ({ error } = await supabase.from('payments').insert({ id: newId, ...payload }));
    }

    setIsLoading(false);
    if (error) {
      setErrors({ _global: error.message });
    } else {
      setGeneratedLink(link);
      setSuccess(true);
      setTimeout(() => router.push('/dashboard/payments'), 2500);
    }
  }

  if (success) {
    return (
      <div className="bg-white/[0.03] border border-white/6 rounded-2xl p-10 flex flex-col items-center gap-5 text-center">
        <div className="w-14 h-14 rounded-full bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center">
          <CheckCircle2 className="w-7 h-7 text-emerald-400" />
        </div>
        <div>
          <p className="text-white font-semibold text-lg">Invoice {isEdit ? 'updated' : 'created'}!</p>
          <p className="text-white/30 text-sm mt-1">Redirecting to payment list…</p>
        </div>
        {generatedLink && (
          <div className="w-full bg-white/5 border border-white/8 rounded-xl p-4">
            <p className="text-white/40 text-xs mb-2 flex items-center gap-1.5">
              <Link2 className="w-3.5 h-3.5" /> Mock payment link generated
            </p>
            <p className="font-mono text-violet-300 text-sm break-all">{generatedLink}</p>
          </div>
        )}
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {errors._global && (
        <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20">
          <p className="text-red-300 text-sm">{errors._global}</p>
        </div>
      )}

      {/* Customer & Status */}
      <div className="bg-white/[0.03] border border-white/6 rounded-2xl p-6 space-y-5">
        <p className="text-white/40 text-xs font-medium uppercase tracking-wider">Invoice Details</p>

        {/* Customer select */}
        <div className="space-y-1.5">
          <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
            <User className="w-3.5 h-3.5 text-white/25" />
            Customer <span className="text-violet-400">*</span>
          </label>
          {customers.length === 0 ? (
            <div className="p-3 rounded-xl bg-amber-500/8 border border-amber-500/15">
              <p className="text-amber-300/70 text-sm">
                No customers yet.{' '}
                <a href="/dashboard/customers/new" className="text-amber-300 underline">Add one first →</a>
              </p>
            </div>
          ) : (
            <select
              value={form.customer_id}
              onChange={e => set('customer_id', e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl text-sm bg-white/[0.04] border text-white/80 focus:outline-none focus:ring-1 transition-all appearance-none cursor-pointer ${
                errors.customer_id
                  ? 'border-red-500/40 focus:border-red-500/60 focus:ring-red-500/20'
                  : 'border-white/8 focus:border-violet-500/50 focus:ring-violet-500/20'
              }`}
            >
              <option value="" className="bg-[#16162A]">— Select customer —</option>
              {customers.map(c => (
                <option key={c.id} value={c.id} className="bg-[#16162A]">
                  {c.name}{c.company ? ` · ${c.company}` : ''}
                </option>
              ))}
            </select>
          )}
          {errors.customer_id && <p className="text-red-400/80 text-xs">{errors.customer_id}</p>}
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Amount */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
              <DollarSign className="w-3.5 h-3.5 text-white/25" />
              Invoice amount ({sym}) <span className="text-violet-400">*</span>
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={form.amount}
              onChange={e => set('amount', e.target.value)}
              placeholder="0.00"
              className={`w-full px-4 py-2.5 rounded-xl text-sm bg-white/[0.04] border text-white/80 placeholder-white/20 focus:outline-none focus:ring-1 transition-all font-mono ${
                errors.amount
                  ? 'border-red-500/40 focus:border-red-500/60 focus:ring-red-500/20'
                  : 'border-white/8 focus:border-violet-500/50 focus:ring-violet-500/20'
              }`}
            />
            {errors.amount && <p className="text-red-400/80 text-xs">{errors.amount}</p>}
          </div>

          {/* Amount paid */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
              <DollarSign className="w-3.5 h-3.5 text-white/25" />
              Amount paid ({sym})
            </label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={form.amount_paid}
              onChange={e => set('amount_paid', e.target.value)}
              placeholder="0.00"
              className={`w-full px-4 py-2.5 rounded-xl text-sm bg-white/[0.04] border text-white/80 placeholder-white/20 focus:outline-none focus:ring-1 transition-all font-mono ${
                errors.amount_paid
                  ? 'border-red-500/40 focus:border-red-500/60 focus:ring-red-500/20'
                  : 'border-white/8 focus:border-violet-500/50 focus:ring-violet-500/20'
              }`}
            />
            {errors.amount_paid && <p className="text-red-400/80 text-xs">{errors.amount_paid}</p>}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {/* Invoice # */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
              <Hash className="w-3.5 h-3.5 text-white/25" />
              Invoice number
            </label>
            <input
              type="text"
              value={form.invoice_number}
              onChange={e => set('invoice_number', e.target.value)}
              placeholder="INV-2025-001"
              className="w-full px-4 py-2.5 rounded-xl text-sm bg-white/[0.04] border border-white/8 text-white/80 placeholder-white/20 focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 transition-all font-mono"
            />
          </div>

          {/* Due date */}
          <div className="space-y-1.5">
            <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
              <Calendar className="w-3.5 h-3.5 text-white/25" />
              Due date
            </label>
            <input
              type="date"
              value={form.due_date}
              onChange={e => set('due_date', e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl text-sm bg-white/[0.04] border border-white/8 text-white/80 focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 transition-all"
            />
          </div>
        </div>

        {/* Description */}
        <div className="space-y-1.5">
          <label className="flex items-center gap-1.5 text-sm font-medium text-white/50">
            <FileText className="w-3.5 h-3.5 text-white/25" />
            Description
          </label>
          <textarea
            value={form.description}
            onChange={e => set('description', e.target.value)}
            placeholder="Corporate transport services — Q1 2025…"
            rows={3}
            className="w-full px-4 py-2.5 rounded-xl text-sm bg-white/[0.04] border border-white/8 text-white/80 placeholder-white/20 focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 transition-all resize-none"
          />
        </div>
      </div>

      {/* Status */}
      <div className="bg-white/[0.03] border border-white/6 rounded-2xl p-6 space-y-4">
        <p className="text-white/40 text-xs font-medium uppercase tracking-wider">Invoice Status</p>
        <div className="flex items-center gap-2 flex-wrap">
          {STATUS_OPTIONS.map(opt => (
            <button
              key={opt.value}
              type="button"
              onClick={() => set('status', opt.value)}
              className={`
                px-4 py-2 rounded-xl border text-sm font-medium transition-all
                ${form.status === opt.value ? STATUS_COLORS[opt.value] : 'bg-white/3 border-white/8 text-white/30 hover:text-white/55'}
              `}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-between pt-1">
        <button
          type="button"
          onClick={() => router.back()}
          className="px-4 py-2.5 rounded-xl text-white/40 hover:text-white text-sm font-medium hover:bg-white/5 transition-all"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isLoading || customers.length === 0}
          className="
            flex items-center gap-2 px-6 py-2.5 rounded-xl
            bg-gradient-to-r from-violet-600 to-indigo-600
            hover:from-violet-500 hover:to-indigo-500
            text-white text-sm font-semibold
            disabled:opacity-50 disabled:cursor-not-allowed
            transition-all shadow-lg shadow-violet-500/20
          "
        >
          {isLoading ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> Creating…</>
          ) : (
            <>{isEdit ? 'Update Invoice' : 'Create Invoice & Generate Link'}</>
          )}
        </button>
      </div>
    </form>
  );
}
