'use client';

// ============================================================
// Sidebar — Fixed navigation with active-link highlighting
// ============================================================

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  Users,
  FileText,
  Upload,
  Settings,
  LogOut,
  Zap,
  TrendingUp,
} from 'lucide-react';
import { createClient } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import type { Profile } from '@/types';

const NAV = [
  { label: 'Dashboard',  href: '/dashboard', icon: LayoutDashboard },
  { label: 'Customers',  href: '/dashboard/customers', icon: Users },
  { label: 'Payments',   href: '/dashboard/payments', icon: FileText },
  { label: 'Import',     href: '/dashboard/import', icon: Upload },
  { label: 'Analytics',  href: '/dashboard/analytics', icon: TrendingUp },
];

const BOTTOM_NAV = [
  { label: 'Settings', href: '/dashboard/settings', icon: Settings },
];

interface SidebarProps {
  profile: Profile | null;
}

export default function Sidebar({ profile }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleSignOut() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push('/auth/login');
  }

  const isActive = (href: string) =>
    href === '/dashboard' ? pathname === href : pathname.startsWith(href);

  const initials = profile?.org_name
    ? profile.org_name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
    : profile?.full_name?.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
    ?? '?';

  return (
    <aside className="fixed inset-y-0 left-0 w-56 bg-[#0D0D1A] border-r border-white/5 flex flex-col z-40">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/5">
        <Link href="/dashboard" className="flex items-center gap-3 group">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/20 group-hover:shadow-violet-500/40 transition-shadow">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <div className="min-w-0">
            <p className="text-white font-semibold text-sm tracking-tight leading-none truncate">
              Rego Collections
            </p>
            <p className="text-white/25 text-[10px] mt-0.5 truncate">
              {profile?.org_name ?? 'Your workspace'}
            </p>
          </div>
        </Link>
      </div>

      {/* Primary nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {NAV.map(({ label, href, icon: Icon }) => {
          const active = isActive(href);
          return (
            <Link
              key={href}
              href={href}
              className={`
                flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
                transition-all duration-150 group
                ${active
                  ? 'bg-violet-500/15 text-violet-300 border border-violet-500/20'
                  : 'text-white/40 hover:text-white/80 hover:bg-white/5 border border-transparent'
                }
              `}
            >
              <Icon
                className={`w-4 h-4 flex-shrink-0 transition-colors ${
                  active ? 'text-violet-400' : 'text-white/25 group-hover:text-white/60'
                }`}
              />
              {label}
              {active && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-violet-400" />
              )}
            </Link>
          );
        })}
      </nav>

      {/* Bottom section */}
      <div className="px-3 pb-4 space-y-0.5 border-t border-white/5 pt-4">
        {BOTTOM_NAV.map(({ label, href, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-white/40 hover:text-white/80 hover:bg-white/5 transition-all duration-150"
          >
            <Icon className="w-4 h-4 flex-shrink-0 text-white/25" />
            {label}
          </Link>
        ))}

        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-white/40 hover:text-red-400/80 hover:bg-red-500/5 transition-all duration-150"
        >
          <LogOut className="w-4 h-4 flex-shrink-0 text-white/25" />
          Sign out
        </button>

        {/* Profile chip */}
        <div className="mt-3 flex items-center gap-3 px-3 py-2.5 rounded-xl bg-white/3 border border-white/5">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-500/40 to-indigo-600/40 flex items-center justify-center flex-shrink-0">
            <span className="text-white/80 text-[10px] font-bold">{initials}</span>
          </div>
          <div className="min-w-0">
            <p className="text-white/60 text-xs font-medium truncate">
              {profile?.full_name ?? 'User'}
            </p>
            <p className="text-white/25 text-[10px] truncate">
              {profile?.currency ?? 'INR'} · {profile?.org_name ?? '—'}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
}
