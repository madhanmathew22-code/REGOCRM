// ============================================================
// /dashboard/analytics — Extended analytics view
// ============================================================

import { createServerComponentClient } from '@/lib/supabase';
import { redirect } from 'next/navigation';
import AnalyticsCharts from '@/components/dashboard/AnalyticsCharts';

export const metadata = { title: 'Analytics — Rego Collections' };

export default async function AnalyticsPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('currency, org_name')
    .eq('id', user.id)
    .single();

  const { data: payments } = await supabase
    .from('payments')
    .select('amount, amount_paid, status, created_at, due_date, customers(name, company)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: true });

  const { data: customers } = await supabase
    .from('customers')
    .select('id, name, company, status, created_at')
    .eq('user_id', user.id);

  const currency = profile?.currency ?? 'INR';
  const allPayments = payments ?? [];

  // Build 12-month trend
  const now = new Date();
  const monthlyTrend = Array.from({ length: 12 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (11 - i), 1);
    const label = d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
    const month = allPayments.filter(p => {
      const pd = new Date(p.created_at);
      return pd.getFullYear() === d.getFullYear() && pd.getMonth() === d.getMonth();
    });
    return {
      month: label,
      invoiced:  month.reduce((s, p) => s + Number(p.amount), 0),
      collected: month.reduce((s, p) => s + Number(p.amount_paid), 0),
      overdue:   month.filter(p => p.status === 'overdue').reduce((s, p) => s + Number(p.amount), 0),
      count:     month.length,
    };
  });

  // Status breakdown
  const statusBreakdown = ['draft', 'sent', 'paid', 'overdue', 'partial'].map(s => ({
    status: s,
    count:  allPayments.filter(p => p.status === s).length,
    amount: allPayments.filter(p => p.status === s).reduce((sum, p) => sum + Number(p.amount), 0),
  }));

  // Top customers by invoiced amount
  const customerMap: Record<string, { name: string; company: string | null; total: number; paid: number }> = {};
  allPayments.forEach(p => {
    const name = (p.customers as any)?.name ?? 'Unknown';
    const company = (p.customers as any)?.company ?? null;
    if (!customerMap[name]) customerMap[name] = { name, company, total: 0, paid: 0 };
    customerMap[name].total += Number(p.amount);
    customerMap[name].paid  += Number(p.amount_paid);
  });
  const topCustomers = Object.values(customerMap)
    .sort((a, b) => b.total - a.total)
    .slice(0, 8);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Analytics</h1>
        <p className="text-white/40 text-sm mt-1">
          12-month collection performance for {profile?.org_name ?? 'your workspace'}.
        </p>
      </div>

      <AnalyticsCharts
        monthlyTrend={monthlyTrend}
        statusBreakdown={statusBreakdown}
        topCustomers={topCustomers}
        currency={currency}
        totalCustomers={customers?.length ?? 0}
        totalPayments={allPayments.length}
      />
    </div>
  );
}
