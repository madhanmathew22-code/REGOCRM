// ============================================================
// /dashboard/settings — Profile & organisation settings
// ============================================================

import { redirect } from 'next/navigation';
import { createServerComponentClient } from '@/lib/supabase';
import SettingsForm from '@/components/settings/SettingsForm';

export const metadata = { title: 'Settings — Rego Collections' };

export default async function SettingsPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Settings</h1>
        <p className="text-white/40 text-sm mt-1">
          Manage your organisation profile and preferences.
        </p>
      </div>
      <SettingsForm profile={profile} userEmail={user.email ?? ''} />
    </div>
  );
}
