// ============================================================
// /dashboard/import — Bulk Excel Import Wizard page
// ============================================================

import ImportWizard from '@/components/import/ImportWizard';

export const metadata = {
  title: 'Bulk Import — Rego Collections',
};

export default function ImportPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Bulk Import</h1>
        <p className="text-white/40 text-sm mt-1">
          Upload an Excel or CSV file, map your columns, and push data directly into the CRM.
        </p>
      </div>
      <ImportWizard />
    </div>
  );
}
