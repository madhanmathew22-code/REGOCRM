// ============================================================
// /dashboard/customers/new — Add a single customer
// ============================================================

import { redirect } from 'next/navigation';
import { createServerComponentClient } from '@/lib/supabase';
import CustomerForm from '@/components/customers/CustomerForm';

export const metadata = { title: 'Add Customer — Rego Collections' };

export default async function NewCustomerPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Add Customer</h1>
        <p className="text-white/40 text-sm mt-1">
          Create a new client record in your workspace.
        </p>
      </div>
      <CustomerForm userId={user.id} />
    </div>
  );
}
