// ============================================================
// /dashboard/customers — Customer management table
// ============================================================

import { createServerComponentClient } from '@/lib/supabase';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { UserPlus, Upload } from 'lucide-react';
import CustomersTable from '@/components/customers/CustomersTable';

export const metadata = { title: 'Customers — Rego Collections' };

export default async function CustomersPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('currency')
    .eq('id', user.id)
    .single();

  const { data: customers, count } = await supabase
    .from('customers')
    .select(`
      *,
      payments(amount, amount_paid, status)
    `, { count: 'exact' })
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Customers</h1>
          <p className="text-white/40 text-sm mt-1">
            {count ?? 0} client{count !== 1 ? 's' : ''} in your workspace
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            href="/dashboard/import"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/8 border border-white/10 text-white/60 text-sm font-medium hover:bg-white/12 hover:text-white transition-all"
          >
            <Upload className="w-4 h-4" />
            Bulk Import
          </Link>
          <Link
            href="/dashboard/customers/new"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white text-sm font-semibold hover:opacity-90 transition-all shadow-lg shadow-violet-500/20"
          >
            <UserPlus className="w-4 h-4" />
            Add Customer
          </Link>
        </div>
      </div>

      {/* Table */}
      <CustomersTable
        customers={customers ?? []}
        currency={profile?.currency ?? 'INR'}
      />
    </div>
  );
}
