// ============================================================
// /dashboard — Main CRM Dashboard (Server Component)
// ============================================================

import { createServerComponentClient } from '@/lib/supabase';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import DashboardMetrics from '@/components/dashboard/DashboardMetrics';
import CollectionChart from '@/components/dashboard/CollectionChart';
import RecentPayments from '@/components/dashboard/RecentPayments';
import { Upload, UserPlus, FileText } from 'lucide-react';

export const metadata = { title: 'Dashboard — Rego Collections' };

export default async function DashboardPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  // ── Fetch profile ──────────────────────────────────────
  const { data: profile } = await supabase
    .from('profiles')
    .select('org_name, currency, full_name')
    .eq('id', user.id)
    .single();

  // ── Fetch payments for metrics ─────────────────────────
  const { data: payments } = await supabase
    .from('payments')
    .select('amount, amount_paid, status, created_at, due_date')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  // ── Compute metrics ────────────────────────────────────
  const allPayments = payments ?? [];

  const totalInvoiced = allPayments.reduce((s, p) => s + Number(p.amount), 0);
  const totalCollected = allPayments.reduce((s, p) => s + Number(p.amount_paid), 0);
  const totalPending = allPayments
    .filter(p => ['draft', 'sent', 'partial'].includes(p.status))
    .reduce((s, p) => s + (Number(p.amount) - Number(p.amount_paid)), 0);
  const totalOverdue = allPayments
    .filter(p => p.status === 'overdue')
    .reduce((s, p) => s + (Number(p.amount) - Number(p.amount_paid)), 0);
  const collectionRate = totalInvoiced > 0
    ? Math.round((totalCollected / totalInvoiced) * 100)
    : 0;

  // ── Build monthly chart data (last 6 months) ──────────
  const now = new Date();
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
    const label = d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
    const monthPayments = allPayments.filter(p => {
      const pd = new Date(p.created_at);
      return pd.getFullYear() === d.getFullYear() && pd.getMonth() === d.getMonth();
    });
    return {
      month: label,
      collected: monthPayments.reduce((s, p) => s + Number(p.amount_paid), 0),
      invoiced: monthPayments.reduce((s, p) => s + Number(p.amount), 0),
      overdue: monthPayments
        .filter(p => p.status === 'overdue')
        .reduce((s, p) => s + Number(p.amount), 0),
    };
  });

  // ── Fetch recent payments with customer join ───────────
  const { data: recent } = await supabase
    .from('payments')
    .select('*, customers(name, company)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(8);

  const currency = profile?.currency ?? 'INR';
  const greeting = getGreeting();

  return (
    <div className="space-y-8">
      {/* ── Page header ─────────────────────────────────── */}
      <div className="flex items-start justify-between">
        <div>
          <p className="text-white/30 text-sm">{greeting}</p>
          <h1 className="text-2xl font-bold text-white tracking-tight mt-0.5">
            {profile?.org_name ?? 'Your workspace'}
          </h1>
        </div>

        {/* Quick actions */}
        <div className="flex items-center gap-3">
          <Link
            href="/dashboard/import"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-violet-500/15 border border-violet-500/25 text-violet-300 text-sm font-medium hover:bg-violet-500/25 transition-all"
          >
            <Upload className="w-4 h-4" />
            Bulk Import
          </Link>
          <Link
            href="/dashboard/customers/new"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/8 border border-white/10 text-white/70 text-sm font-medium hover:bg-white/12 hover:text-white transition-all"
          >
            <UserPlus className="w-4 h-4" />
            Add Client
          </Link>
          <Link
            href="/dashboard/payments/new"
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white text-sm font-semibold hover:opacity-90 transition-all shadow-lg shadow-violet-500/20"
          >
            <FileText className="w-4 h-4" />
            New Invoice
          </Link>
        </div>
      </div>

      {/* ── Metric cards ────────────────────────────────── */}
      <DashboardMetrics
        totalCollected={totalCollected}
        totalPending={totalPending}
        totalOverdue={totalOverdue}
        collectionRate={collectionRate}
        currency={currency}
      />

      {/* ── Chart + Recent side by side ─────────────────── */}
      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-7">
          <CollectionChart data={monthlyData} currency={currency} />
        </div>
        <div className="col-span-5">
          <RecentPayments payments={recent ?? []} currency={currency} />
        </div>
      </div>
    </div>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}
