// ============================================================
// /dashboard/payments — Invoice / Payments table
// ============================================================

import { createServerComponentClient } from '@/lib/supabase';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { FilePlus } from 'lucide-react';
import PaymentsTable from '@/components/payments/PaymentsTable';

export const metadata = { title: 'Payments — Rego Collections' };

export default async function PaymentsPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('currency')
    .eq('id', user.id)
    .single();

  const { data: payments, count } = await supabase
    .from('payments')
    .select(`
      *,
      customers(name, email, company)
    `, { count: 'exact' })
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Payments</h1>
          <p className="text-white/40 text-sm mt-1">
            {count ?? 0} invoice{count !== 1 ? 's' : ''} across all clients
          </p>
        </div>
        <Link
          href="/dashboard/payments/new"
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white text-sm font-semibold hover:opacity-90 transition-all shadow-lg shadow-violet-500/20"
        >
          <FilePlus className="w-4 h-4" />
          New Invoice
        </Link>
      </div>

      <PaymentsTable
        payments={payments ?? []}
        currency={profile?.currency ?? 'INR'}
      />
    </div>
  );
}
