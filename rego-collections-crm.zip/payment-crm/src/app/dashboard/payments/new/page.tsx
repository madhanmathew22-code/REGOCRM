// ============================================================
// /dashboard/payments/new — Create a new invoice
// ============================================================

import { redirect } from 'next/navigation';
import { createServerComponentClient } from '@/lib/supabase';
import PaymentForm from '@/components/payments/PaymentForm';

export const metadata = { title: 'New Invoice — Rego Collections' };

export default async function NewPaymentPage() {
  const supabase = await createServerComponentClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('currency')
    .eq('id', user.id)
    .single();

  // Fetch customers for the select
  const { data: customers } = await supabase
    .from('customers')
    .select('id, name, company')
    .eq('user_id', user.id)
    .eq('status', 'active')
    .order('name');

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl font-bold text-white tracking-tight">New Invoice</h1>
        <p className="text-white/40 text-sm mt-1">
          Create a payment record and generate a mock payment link.
        </p>
      </div>
      <PaymentForm
        userId={user.id}
        currency={profile?.currency ?? 'INR'}
        customers={customers ?? []}
      />
    </div>
  );
}
