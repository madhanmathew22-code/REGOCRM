// ============================================================
// Dashboard Layout — wraps all /dashboard/* routes
// ============================================================

import { redirect } from 'next/navigation';
import { createServerComponentClient } from '@/lib/supabase';
import Sidebar from '@/components/Sidebar';
import type { Profile } from '@/types';

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createServerComponentClient();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/auth/login');

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  if (!profile?.onboarded) redirect('/onboarding');

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Sidebar profile={profile as Profile} />

      {/* Main content — offset by sidebar width */}
      <main className="ml-56 min-h-screen">
        <div className="max-w-7xl mx-auto px-6 py-8">
          {children}
        </div>
      </main>
    </div>
  );
}
