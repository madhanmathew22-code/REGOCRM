'use client';

// ============================================================
// Login UI — Google OAuth Sign-In
// ============================================================

import { useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { AlertCircle, Zap } from 'lucide-react';

interface LoginContentProps {
  signInAction: () => Promise<void>;
}

const ERROR_MESSAGES: Record<string, string> = {
  oauth_failed: 'Google sign-in failed. Please try again.',
  oauth_callback_failed: 'Authentication callback failed. Please try again.',
  default: 'Something went wrong. Please try again.',
};

export default function LoginContent({ signInAction }: LoginContentProps) {
  const params = useSearchParams();
  const errorKey = params.get('error') ?? '';
  const errorMessage = ERROR_MESSAGES[errorKey] ?? (errorKey ? ERROR_MESSAGES.default : null);

  const [isLoading, setIsLoading] = useState(false);

  async function handleSignIn() {
    setIsLoading(true);
    await signInAction();
    // Redirect happens server-side; this runs only on error
    setIsLoading(false);
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex">
      {/* ── Left branding panel ── */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12 bg-gradient-to-br from-[#0D0D1A] to-[#0A0A0F] border-r border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <span className="text-white font-semibold tracking-tight">Rego Collections</span>
        </div>

        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold text-white leading-tight tracking-tight">
              Collections that<br />
              <span className="bg-gradient-to-r from-violet-400 to-indigo-400 bg-clip-text text-transparent">
                close faster.
              </span>
            </h1>
            <p className="mt-4 text-white/40 text-lg leading-relaxed max-w-sm">
              Track invoices, chase payments, and import client data from Excel — all in one clean workspace built for corporate transport ops.
            </p>
          </div>

          {/* Stats strip */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { value: '₹2.4Cr', label: 'Avg monthly tracked' },
              { value: '94%', label: 'Collection rate' },
              { value: '12 min', label: 'Avg import time' },
            ].map((s) => (
              <div key={s.label} className="p-4 rounded-xl bg-white/5 border border-white/5">
                <p className="text-xl font-bold text-white">{s.value}</p>
                <p className="text-xs text-white/30 mt-1">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Testimonial */}
          <blockquote className="border-l-2 border-violet-500/50 pl-4">
            <p className="text-white/50 text-sm leading-relaxed italic">
              "Reduced our overdue AR from ₹48L to ₹9L in two months. The bulk import saved hours every week."
            </p>
            <footer className="mt-2 text-white/30 text-xs">
              — Collections Lead, Enterprise Mobility Firm
            </footer>
          </blockquote>
        </div>

        <p className="text-white/20 text-xs">
          © 2025 Rego Mobility. All data encrypted at rest.
        </p>
      </div>

      {/* ── Right sign-in panel ── */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm space-y-8">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="text-white font-semibold tracking-tight">Rego Collections</span>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-white tracking-tight">Sign in</h2>
            <p className="mt-2 text-white/40 text-sm">
              Use your company Google account to continue.
            </p>
          </div>

          {/* Error alert */}
          {errorMessage && (
            <div className="flex items-start gap-3 p-4 rounded-xl bg-red-500/10 border border-red-500/20">
              <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              <p className="text-red-300 text-sm">{errorMessage}</p>
            </div>
          )}

          {/* Google Sign-In button */}
          <form action={handleSignIn}>
            <button
              type="submit"
              disabled={isLoading}
              className="
                w-full flex items-center justify-center gap-3
                px-5 py-3.5 rounded-xl
                bg-white hover:bg-white/90
                text-gray-900 font-medium text-sm
                transition-all duration-200
                disabled:opacity-60 disabled:cursor-not-allowed
                shadow-lg shadow-black/20
                focus:outline-none focus:ring-2 focus:ring-violet-500/50
              "
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-gray-400 border-t-gray-800 rounded-full animate-spin" />
              ) : (
                <GoogleIcon />
              )}
              <span>
                {isLoading ? 'Signing in…' : 'Continue with Google'}
              </span>
            </button>
          </form>

          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-white/5" />
              <span className="text-white/20 text-xs">Secure access</span>
              <div className="flex-1 h-px bg-white/5" />
            </div>

            <p className="text-center text-white/25 text-xs leading-relaxed">
              By signing in, you agree to our{' '}
              <a href="#" className="text-white/40 underline underline-offset-2 hover:text-white/60">
                Terms of Service
              </a>{' '}
              and{' '}
              <a href="#" className="text-white/40 underline underline-offset-2 hover:text-white/60">
                Privacy Policy
              </a>
              . Your data is encrypted end-to-end.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg className="w-5 h-5" viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
        fill="#4285F4"
      />
      <path
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
        fill="#34A853"
      />
      <path
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
        fill="#FBBC05"
      />
      <path
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
        fill="#EA4335"
      />
    </svg>
  );
}
