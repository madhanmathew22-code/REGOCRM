// ============================================================
// /auth/login — Sign-in with Google
// ============================================================

import { Suspense } from 'react';
import { signInWithGoogle } from '@/lib/auth-actions';
import LoginContent from './LoginContent';

export const metadata = {
  title: 'Sign In — Rego Collections CRM',
  description: 'Secure sign-in for your payment collection workspace.',
};

export default function LoginPage() {
  return (
    <Suspense>
      <LoginContent signInAction={signInWithGoogle} />
    </Suspense>
  );
}
