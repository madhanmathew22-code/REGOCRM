// ============================================================
// /auth/callback — Supabase OAuth exchange
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { createActionClient } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  const next = searchParams.get('next') ?? '/dashboard';

  if (code) {
    const supabase = await createActionClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      // Middleware will intercept and redirect to /onboarding if needed
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  return NextResponse.redirect(`${origin}/auth/error?reason=oauth_callback_failed`);
}
