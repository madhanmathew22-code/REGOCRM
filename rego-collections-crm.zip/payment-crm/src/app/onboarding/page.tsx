'use client';

// ============================================================
// /onboarding — Org name + currency setup (new users only)
// ============================================================

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Building2, ChevronRight, Zap, CheckCircle2 } from 'lucide-react';
import { createClient } from '@/lib/supabase';

const CURRENCIES = [
  { code: 'INR', label: 'Indian Rupee', symbol: '₹' },
  { code: 'USD', label: 'US Dollar', symbol: '$' },
  { code: 'EUR', label: 'Euro', symbol: '€' },
  { code: 'GBP', label: 'British Pound', symbol: '£' },
  { code: 'AED', label: 'UAE Dirham', symbol: 'د.إ' },
  { code: 'SGD', label: 'Singapore Dollar', symbol: 'S$' },
];

export default function OnboardingPage() {
  const router = useRouter();
  const [orgName, setOrgName] = useState('');
  const [currency, setCurrency] = useState('INR');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [step, setStep] = useState<'form' | 'success'>('form');

  const isValid = orgName.trim().length >= 2;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isValid || isLoading) return;

    setIsLoading(true);
    setError(null);

    try {
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();

      if (!user) {
        router.push('/auth/login');
        return;
      }

      const { error: updateError } = await supabase
        .from('profiles')
        .update({ org_name: orgName.trim(), currency, onboarded: true })
        .eq('id', user.id);

      if (updateError) throw new Error(updateError.message);

      setStep('success');
      setTimeout(() => router.push('/dashboard'), 1200);
    } catch (err: any) {
      setError(err.message ?? 'Something went wrong. Please try again.');
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center p-6">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-violet-600/10 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-lg">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-10">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/25">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <span className="text-white font-semibold tracking-tight text-lg">Rego Collections</span>
        </div>

        {step === 'success' ? (
          /* ── Success state ── */
          <div className="text-center space-y-4 py-12">
            <div className="w-16 h-16 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">You're all set!</h2>
              <p className="text-white/40 mt-2 text-sm">Taking you to your dashboard…</p>
            </div>
            <div className="w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : (
          /* ── Setup form ── */
          <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-8 backdrop-blur-sm">
            {/* Header */}
            <div className="mb-8">
              <div className="w-12 h-12 rounded-xl bg-violet-500/15 border border-violet-500/20 flex items-center justify-center mb-5">
                <Building2 className="w-5 h-5 text-violet-400" />
              </div>
              <h1 className="text-2xl font-bold text-white tracking-tight">
                Set up your workspace
              </h1>
              <p className="mt-2 text-white/40 text-sm leading-relaxed">
                Tell us about your organisation so we can personalise your collections dashboard.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Org Name */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-white/60" htmlFor="org_name">
                  Organisation name <span className="text-violet-400">*</span>
                </label>
                <input
                  id="org_name"
                  type="text"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  placeholder="e.g. Rego Mobility Pvt Ltd"
                  maxLength={120}
                  className="
                    w-full px-4 py-3 rounded-xl
                    bg-white/5 border border-white/10
                    text-white placeholder-white/20
                    text-sm
                    focus:outline-none focus:border-violet-500/60 focus:ring-2 focus:ring-violet-500/20
                    transition-all
                  "
                />
                {orgName.length > 0 && orgName.trim().length < 2 && (
                  <p className="text-amber-400/80 text-xs">Minimum 2 characters required.</p>
                )}
              </div>

              {/* Currency */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-white/60" htmlFor="currency">
                  Default currency
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {CURRENCIES.map((c) => (
                    <button
                      key={c.code}
                      type="button"
                      onClick={() => setCurrency(c.code)}
                      className={`
                        flex flex-col items-start px-3 py-2.5 rounded-xl border text-left
                        transition-all duration-150
                        ${currency === c.code
                          ? 'bg-violet-500/15 border-violet-500/50 text-white'
                          : 'bg-white/3 border-white/8 text-white/40 hover:text-white/70 hover:border-white/15'
                        }
                      `}
                    >
                      <span className="font-mono text-base font-semibold leading-none">
                        {c.symbol}
                      </span>
                      <span className="text-[10px] mt-1.5 opacity-70">{c.code}</span>
                    </button>
                  ))}
                </div>
                <p className="text-white/25 text-xs">
                  {CURRENCIES.find(c => c.code === currency)?.label} selected
                </p>
              </div>

              {/* Error */}
              {error && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20">
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={!isValid || isLoading}
                className="
                  w-full flex items-center justify-center gap-2
                  px-5 py-3.5 rounded-xl
                  bg-gradient-to-r from-violet-600 to-indigo-600
                  hover:from-violet-500 hover:to-indigo-500
                  text-white font-semibold text-sm
                  transition-all duration-200
                  disabled:opacity-40 disabled:cursor-not-allowed
                  shadow-lg shadow-violet-500/25
                  focus:outline-none focus:ring-2 focus:ring-violet-500/50
                "
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Saving…</span>
                  </>
                ) : (
                  <>
                    <span>Launch dashboard</span>
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Progress dots */}
            <div className="flex justify-center gap-2 mt-8">
              <div className="w-6 h-1 rounded-full bg-violet-500" />
              <div className="w-2 h-1 rounded-full bg-white/15" />
              <div className="w-2 h-1 rounded-full bg-white/15" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
