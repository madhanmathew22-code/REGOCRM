// ============================================================
// Root App Layout — global fonts, metadata, providers
// ============================================================

import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: 'Rego Collections CRM',
    template: '%s — Rego Collections',
  },
  description:
    'Enterprise payment collection CRM for corporate mobility and fleet operations.',
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="font-sans antialiased bg-[#0A0A0F] text-white min-h-screen">
        {children}
      </body>
    </html>
  );
}
