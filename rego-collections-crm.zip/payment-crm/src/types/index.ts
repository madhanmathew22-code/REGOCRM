// ============================================================
// Payment Collection CRM — Shared TypeScript Types
// ============================================================

export type Currency = 'INR' | 'USD' | 'EUR' | 'GBP' | 'AED' | 'SGD';

export type CustomerStatus = 'active' | 'inactive' | 'blocked';

export type PaymentStatus = 'draft' | 'sent' | 'paid' | 'overdue' | 'partial';

// ── Database row shapes (mirrors Supabase schema) ──────────

export interface Profile {
  id: string;
  org_name: string | null;
  currency: Currency;
  full_name: string | null;
  avatar_url: string | null;
  onboarded: boolean;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: string;
  user_id: string;
  name: string;
  email: string | null;
  phone: string | null;
  company: string | null;
  status: CustomerStatus;
  tags: string[] | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: string;
  customer_id: string;
  user_id: string;
  invoice_number: string | null;
  amount: number;
  amount_paid: number;
  due_date: string | null;
  paid_date: string | null;
  status: PaymentStatus;
  payment_link_mock: string | null;
  description: string | null;
  created_at: string;
  updated_at: string;
  // joined
  customers?: Pick<Customer, 'name' | 'email' | 'company'>;
}

// ── Dashboard metric aggregates ────────────────────────────

export interface DashboardMetrics {
  totalCollected: number;
  totalPending: number;
  totalOverdue: number;
  collectionRate: number; // 0–100 percentage
  invoiceCount: number;
}

export interface MonthlyData {
  month: string;           // "Jan 2025"
  collected: number;
  invoiced: number;
  overdue: number;
}

// ── Excel / CSV import types ───────────────────────────────

export type ImportField =
  | 'name'
  | 'email'
  | 'phone'
  | 'company'
  | 'amount'
  | 'due_date'
  | 'invoice_number'
  | 'description'
  | '__skip__';

export interface ColumnMapping {
  excelHeader: string;
  mappedField: ImportField;
}

export type ValidationStatus = 'valid' | 'warning' | 'error';

export interface ImportRowValidation {
  rowIndex: number;
  status: ValidationStatus;
  errors: string[];
  warnings: string[];
}

export interface ParsedImportRow {
  [key: string]: string | number | null;
}

export interface MappedImportRow {
  name: string;
  email?: string;
  phone?: string;
  company?: string;
  amount?: number;
  due_date?: string;
  invoice_number?: string;
  description?: string;
  _validation: ImportRowValidation;
}

// ── UI state types ─────────────────────────────────────────

export type ImportStep = 'upload' | 'mapping' | 'validation' | 'importing' | 'done';

export interface ImportState {
  step: ImportStep;
  rawHeaders: string[];
  rawRows: ParsedImportRow[];
  columnMappings: ColumnMapping[];
  mappedRows: MappedImportRow[];
  importedCount: number;
  errorCount: number;
}

export interface NavItem {
  label: string;
  href: string;
  icon: string;
  badge?: number;
}

// ── Supabase helpers ───────────────────────────────────────

export type SupabaseError = {
  message: string;
  code?: string;
};

export interface ApiResponse<T> {
  data: T | null;
  error: SupabaseError | null;
}
