'use server';

// ============================================================
// Server Actions — Auth & Profile
// ============================================================

import { redirect } from 'next/navigation';
import { createActionClient } from './supabase';
import type { Currency } from '@/types';

// ── Google OAuth Sign-In ───────────────────────────────────
export async function signInWithGoogle() {
  const supabase = await createActionClient();

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
      queryParams: {
        access_type: 'offline',
        prompt: 'consent',
      },
    },
  });

  if (error) {
    console.error('[Auth] Google sign-in error:', error.message);
    return redirect('/auth/login?error=oauth_failed');
  }

  if (data.url) {
    return redirect(data.url);
  }
}

// ── Sign-Out ───────────────────────────────────────────────
export async function signOut() {
  const supabase = await createActionClient();
  await supabase.auth.signOut();
  redirect('/auth/login');
}

// ── Complete Onboarding ────────────────────────────────────
export async function completeOnboarding(formData: FormData) {
  const supabase = await createActionClient();

  const {
    data: { user },
    error: userError,
  } = await supabase.auth.getUser();

  if (userError || !user) {
    return redirect('/auth/login');
  }

  const orgName = (formData.get('org_name') as string)?.trim();
  const currency = (formData.get('currency') as Currency) ?? 'INR';

  if (!orgName || orgName.length < 2) {
    return { error: 'Organisation name must be at least 2 characters.' };
  }

  const { error: updateError } = await supabase
    .from('profiles')
    .update({
      org_name: orgName,
      currency,
      onboarded: true,
    })
    .eq('id', user.id);

  if (updateError) {
    console.error('[Onboarding] Update error:', updateError.message);
    return { error: 'Failed to save your details. Please try again.' };
  }

  redirect('/dashboard');
}

// ── Get Current Profile ────────────────────────────────────
export async function getCurrentProfile() {
  const supabase = await createActionClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();

  return profile;
}
