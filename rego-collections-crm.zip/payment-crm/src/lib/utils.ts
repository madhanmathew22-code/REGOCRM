// ============================================================
// Shared Utility Functions
// ============================================================

const CURRENCY_LOCALES: Record<string, string> = {
  INR: 'en-IN',
  USD: 'en-US',
  EUR: 'de-DE',
  GBP: 'en-GB',
  AED: 'ar-AE',
  SGD: 'en-SG',
};

/**
 * Format a number as currency string with the correct locale.
 */
export function formatCurrency(amount: number, currency: string = 'INR'): string {
  const locale = CURRENCY_LOCALES[currency] ?? 'en-IN';
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Compact currency for chart axes (₹1.2L, $1.2M, etc.)
 */
export function shortCurrency(amount: number, currency: string = 'INR'): string {
  const symbol = getCurrencySymbol(currency);
  if (amount >= 10_000_000) return `${symbol}${(amount / 10_000_000).toFixed(1)}Cr`;
  if (amount >= 100_000)    return `${symbol}${(amount / 100_000).toFixed(1)}L`;
  if (amount >= 1_000)      return `${symbol}${(amount / 1_000).toFixed(1)}K`;
  return `${symbol}${amount.toFixed(0)}`;
}

export function getCurrencySymbol(currency: string): string {
  const symbols: Record<string, string> = {
    INR: '₹', USD: '$', EUR: '€', GBP: '£', AED: 'د.إ', SGD: 'S$',
  };
  return symbols[currency] ?? currency;
}

/**
 * Format ISO date string to local display string.
 */
export function formatDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
  });
}

/**
 * Return a 'X days ago' or 'Due in X days' label.
 */
export function relativeDueDate(dateStr: string | null | undefined): string {
  if (!dateStr) return '';
  const diff = Math.round((new Date(dateStr).getTime() - Date.now()) / 86_400_000);
  if (diff < 0)  return `${Math.abs(diff)}d overdue`;
  if (diff === 0) return 'Due today';
  return `Due in ${diff}d`;
}

/**
 * Truncate a string and append ellipsis.
 */
export function truncate(str: string, max: number): string {
  return str.length > max ? str.slice(0, max - 1) + '…' : str;
}

/**
 * Generate a random mock payment link.
 */
export function mockPaymentLink(invoiceId: string): string {
  return `https://pay.rego.co/${invoiceId.slice(0, 8)}`;
}

/**
 * Derive status from due date (for auto-marking overdue).
 */
export function derivePaymentStatus(
  currentStatus: string,
  dueDate: string | null,
  amountPaid: number,
  amount: number
): string {
  if (currentStatus === 'paid') return 'paid';
  if (amountPaid > 0 && amountPaid < amount) return 'partial';
  if (dueDate && new Date(dueDate) < new Date() && currentStatus !== 'paid') return 'overdue';
  return currentStatus;
}
