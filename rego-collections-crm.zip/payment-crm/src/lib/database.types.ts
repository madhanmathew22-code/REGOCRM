// ============================================================
// Auto-generated Supabase database types
// Re-generate with: npx supabase gen types typescript --local
// ============================================================

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          org_name: string | null;
          currency: string;
          full_name: string | null;
          avatar_url: string | null;
          onboarded: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          org_name?: string | null;
          currency?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          onboarded?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          org_name?: string | null;
          currency?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          onboarded?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      customers: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          email: string | null;
          phone: string | null;
          company: string | null;
          status: string;
          tags: string[] | null;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          name: string;
          email?: string | null;
          phone?: string | null;
          company?: string | null;
          status?: string;
          tags?: string[] | null;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          name?: string;
          email?: string | null;
          phone?: string | null;
          company?: string | null;
          status?: string;
          tags?: string[] | null;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      payments: {
        Row: {
          id: string;
          customer_id: string;
          user_id: string;
          invoice_number: string | null;
          amount: number;
          amount_paid: number;
          due_date: string | null;
          paid_date: string | null;
          status: string;
          payment_link_mock: string | null;
          description: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          customer_id: string;
          user_id: string;
          invoice_number?: string | null;
          amount: number;
          amount_paid?: number;
          due_date?: string | null;
          paid_date?: string | null;
          status?: string;
          payment_link_mock?: string | null;
          description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          customer_id?: string;
          user_id?: string;
          invoice_number?: string | null;
          amount?: number;
          amount_paid?: number;
          due_date?: string | null;
          paid_date?: string | null;
          status?: string;
          payment_link_mock?: string | null;
          description?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
    Views: {
      payment_summary: {
        Row: {
          user_id: string | null;
          month: string | null;
          invoice_count: number | null;
          total_invoiced: number | null;
          total_collected: number | null;
          total_outstanding: number | null;
          paid_amount: number | null;
          overdue_amount: number | null;
          pending_amount: number | null;
        };
      };
    };
    Functions: {};
    Enums: {};
  };
}
