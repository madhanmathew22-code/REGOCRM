/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable React strict mode for better DX
  reactStrictMode: true,

  // Allow Supabase storage image domains
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '*.supabase.co',
        pathname: '/storage/v1/object/public/**',
      },
      {
        protocol: 'https',
        hostname: 'lh3.googleusercontent.com', // Google avatar URLs
      },
    ],
  },

  // Silence known warning from xlsx peer dep
  webpack: (config) => {
    config.resolve.alias.canvas = false;
    return config;
  },
};

module.exports = nextConfig;
